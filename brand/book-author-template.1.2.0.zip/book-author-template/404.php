<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package Book Author Template
 */
get_header();
// Custom 404 Logic
$awt_settings = get_option('awt_global_settings', []);
$slug = isset($awt_settings['awt_404_template_id']) ? $awt_settings['awt_404_template_id'] : '';
$custom_404_rendered = false;

if (!empty($slug) && function_exists('rswpthemes_awt_get_block_id_by_slug')) {
	$block_id = rswpthemes_awt_get_block_id_by_slug($slug);
	if ($block_id) {
		// Echo the custom block
		echo do_blocks('<!-- wp:block {"ref":' . absint($block_id) . '} /-->');
		$custom_404_rendered = true;
	}
}

if (!$custom_404_rendered):
	?>
	<div id="primary" class="content-area">
		<main id="main" class="site-main">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<section class="error-404 not-found">
							<header class="page-header">
								<h1 class="page-title"><?php esc_html_e( 'Oops! That page can&rsquo;t be found.', 'book-author-template' ); ?></h1>
							</header><!-- .page-header -->
							<div class="page-content">
								<p><?php esc_html_e( 'It looks like nothing was found at this location. Maybe try one of the links below or a search?', 'book-author-template' ); ?></p>
								<?php get_search_form(); ?>
							</div><!-- .page-content -->
						</section><!-- .error-404 -->
					</div>
				</div>
				<aside id="secondary" class="row widget-area">
					<div class="col-md-4 pr-xl-5">
						<?php the_widget('WP_Widget_Categories', array('count' => 1)); ?>
					</div>
					<div class="col-md-4 pr-xl-5">
						<?php the_widget('WP_Widget_Recent_Posts', array('title' => __( 'Recent Posts','book-author-template' ), 'number' => 6)); ?>
					</div>
					<div class="col-md-4">
						<?php the_widget('WP_Widget_Tag_Cloud'); ?>
					</div>
				</div>
			</div>
		</main><!-- #main -->
	</div><!-- #primary -->
	<?php
endif;
get_footer(); ?>
