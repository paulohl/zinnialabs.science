<?php
/**
 * Event Archive template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Book Author Template
 */
get_header();

?>
<div id="primary" class="content-area">
	<main id="main" class="site-main">
	<?php
		do_action( 'book_author_template_before_default_page' );
		if ( have_posts() ) :
			$eventIndex = 0;
			$row_reverse = '';
			while ( have_posts() ) :
				the_post();
				$eventIndex++;
				if($eventIndex % 2 == 0 ){
					$row_reverse = 'flex-row-reverse';
				}
				$args = array(
					'row_class' => $row_reverse
				);
				get_template_part( 'template-parts/content/content', get_post_type(), $args);
			endwhile;
				book_author_template_navigation();
			else :
				get_template_part( 'template-parts/content/content', 'none' );
		endif;
		do_action( 'book_author_template_after_default_page' );
		?>
	</main><!-- #main -->
</div>
<?php
get_footer();
