// Prevent Scrolling while clicking on toggle button
jQuery(document).ready(function($) {
    $('.customize-control-kirki-toggle').on('click', function(event) {
        event.preventDefault();

        // Get the setting ID from the data attribute
        var settingId = $(this).data('kirki-setting');

        // Toggle the value of the setting
        wp.customize(settingId, function(value) {
            value.set(!value.get());
        });

        return false;
    });
});
