(function($) {
    "use strict";
    $('.active-single-gallery').slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        dots: true,
        arrows: true,
        fade: true,
        nextArrow: '<div class="slick-next"><i class="icon-arrow-right-solid"></i></div>',
        prevArrow: '<div class="slick-prev"><i class="icon-arrow-left-solid"></i></div>',
    });
    $('.active-product-related-post-slider').slick({
        slidesToShow: 4,
        slidesToScroll: 1,
        dots: false,
        arros: true,
        centerMode: false,
        focusOnSelect: true,
        nextArrow: '<div class="slick-next"><i class="icon-arrow-right-solid"></i></div>',
        prevArrow: '<div class="slick-prev"><i class="icon-arrow-left-solid"></i></div>',
    });
})(jQuery);