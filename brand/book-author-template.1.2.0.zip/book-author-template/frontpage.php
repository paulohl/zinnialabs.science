<?php
/**
 * Template Name: Author Landing Page
 * Template Post Type: page
 *
 * @package Book Author Template
 */
get_header();
?>
<div class="rswpthemes-book-author-template-front-page-container">
	<?php
	$template_parts = get_theme_mod( 'book_author_template_sections' );
	if (is_array($template_parts) && !empty($template_parts)) :
		foreach ( $template_parts as $template_part ) {
			get_template_part( 'template-parts/frontpage-sections/' . $template_part );
		}
	endif;
	?>
</div>
<?php
get_footer();
