<?php
/**
 * book_author_template_setup functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Book Author Template
 */
if ( ! function_exists( 'book_author_template_setup' ) ) :
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 */
	function book_author_template_setup() {

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );
		/*
		 * Let WordPress manage the document title.
		 * By adding theme support, we declare that this theme does not use a
		 * hard-coded <title> tag in the document head, and expect WordPress to
		 * provide it for us.
		 */
		add_theme_support( 'title-tag' );
		add_theme_support( 'align-wide' );
		add_theme_support( 'post-thumbnails' );
		add_image_size( 'book-author-template-recent-post', 120, 132, true );
		add_image_size( 'book-author-template-thumbnail-mobile', 350, 350, true );
		add_image_size( 'book-author-template-list-thumbnail', 380, 360, true );
		add_image_size( 'book-author-template-grid-thumbnail', 380, 320, true );
		add_image_size( 'book-author-template-thumbnail-medium', 770, 433.13, true );
		add_image_size( 'book-author-template-thumbnail-large', 1200, 675, true );
		add_image_size( 'book-author-template-thumbnail-featured', 930, 650, true );
		add_image_size( 'book-author-template-header-single-product', 1080, 1080, true );
		add_image_size( 'book-author-template-header-full', 1920, 1080, true );
		add_image_size( 'book-author-template-latest-post-widget-thumb', 120, 120, true );
		// This theme uses wp_nav_menu() in one location.
		register_nav_menus(
			array(
				'main-menu' => esc_html__( 'Primary', 'book-author-template' ),
				'footer-menu' => esc_html__( 'Footer Menu', 'book-author-template' ),
			)
		);
		add_theme_support( 'woocommerce' );
		/*
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 */
		$html5_support_args = array(
				'comment-form',
				'comment-list',
				'gallery',
				'caption',
				);
	// Set up the WordPress core custom background feature.
	$custom_bg_args = apply_filters( 'book_author_template_custom_background_args', array(
				'default-color' => 'ffffff',
				'default-image' => '',
			)
		);
		add_post_type_support('page', 'excerpt');
		add_theme_support( 'custom-background', $custom_bg_args);
		// Add theme support for selective refresh for widgets.
		add_theme_support( 'customize-selective-refresh-widgets' );
		// Add theme support for selective refresh for widgets.
		add_theme_support( 'editor-styles' );
		add_theme_support( 'wp-block-styles' );
		add_theme_support( 'responsive-embeds' );
		/**
		 * Remove Theme Support
		 */
		remove_theme_support( 'widgets-block-editor' );
		/**
		 * Add support for core custom logo.
		 *
		 * @link https://codex.wordpress.org/Theme_Logo
		 */
		$custom_logo_args = array(
			);
	add_theme_support( 'custom-logo', $custom_logo_args );

	// Set up custom header with default text color
	$custom_header_args = array(
		'default-text-color' => '000000',
		'width' => 2000,
		'height' => 500,
		'flex-width' => true,
		'flex-height' => true,
	);
	add_theme_support( 'custom-header', $custom_header_args );

		$GLOBALS['content_width'] = apply_filters( 'book_author_template_content_width', 640 );
	}
endif;
add_action( 'after_setup_theme', 'book_author_template_setup' );

/**
 * Getting Started
 */
require get_template_directory() . '/inc/getting-started/getting-started.php';

/**
 * Admin Notice
 */
require get_template_directory() . '/inc/welcome/welcome-notice.php';

/**
 * Plugins Installer
 */
require get_template_directory() . '/inc/welcome/plugins-installer.php';

/**
 * Required and Recommended Plugins
 */
require get_template_directory() . '/inc/plugins/tgm/required-plugins.php';
/**
 * Register widgets
 */
require get_template_directory() . '/inc/register-widgets.php';

/**
 * Enqueue scripts
 */
require get_template_directory() . '/inc/enqueue-scripts.php';
/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';
/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';
/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';
/**
 * RS Personal Blog Comment Template.
 */
require get_template_directory() . '/inc/comment-template.php';
/**
 * RS Personal Blog sanitize functions.
 */
require get_template_directory() . '/inc/sanitize-functions.php';
/**
 * Checkout Fields
 */
require get_template_directory() . '/inc/checkout-fields.php';

/**
 * Kirki Plugin Activation
 */
require get_template_directory() . '/inc/plugins/kirki/kirki.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer/customizer.php';

/**
 * Sidebar Control
 */
require get_template_directory() . '/inc/sidebar-control.php';

/**
 * Related Posts.
 */
require get_template_directory() . '/inc/recomended-posts.php';

/**
 * Widgets
 */
require get_template_directory() . '/inc/widgets.php';

/**
 * Meta Fields
 */
require get_template_directory() . '/inc/meta-fields.php';

/**
 * WooCommerce Medifications
 */
if ( class_exists( 'woocommerce' ) ) {
	require get_template_directory() . '/inc/woocommerce-modification.php';
}

/**
 * Go Pro
 */
require get_template_directory() . '/inc/customizer/go-pro/class-customize.php';