<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Book Author Template
 */
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="http://gmpg.org/xfn/11">

	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
	<a class="skip-link screen-reader-text" href="#content"><?php esc_html_e( 'Skip to content', 'book-author-template' ); ?></a>
	<?php
	if ( function_exists( 'wp_body_open' ) ) {
		wp_body_open();
	} else {
		do_action( 'wp_body_open' );
	}
	?>
<div id="page" class="site">
	<div id="preloader-wrapper">
		<div id="preloader"></div>
	</div>
	<?php
	$awt_settings = get_option('awt_global_settings', []);
	$awt_header_force = isset($awt_settings['awt_header_force_global']) && $awt_settings['awt_header_force_global'] === '1';

	if ($awt_header_force) {
		$header_slug = $awt_settings['awt_global_header_block'] ?? '';
		$header_id = function_exists('rswpthemes_awt_get_block_id_by_slug') ? rswpthemes_awt_get_block_id_by_slug($header_slug) : false;

		if ($header_id) {
			echo do_blocks('<!-- wp:block {"ref":' . $header_id . '} /-->');
		} else {
			get_template_part('template-parts/header/header', 'one');
		}
	} else {
		get_template_part('template-parts/header/header', 'one');
	}
	?>
<div id="content" class="site-content">
