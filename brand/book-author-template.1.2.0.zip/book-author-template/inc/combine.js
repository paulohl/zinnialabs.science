const fs = require('fs');
const path = require('path');

// যে ফোল্ডারগুলো স্কিপ করতে চান
const ignoreFolders = ['node_modules', '.git', 'vendor', 'images', 'assets', 'build', 'fonts', 'plugins'];

// যে নির্দিষ্ট ফাইলগুলো স্কিপ করতে চান (স্ক্রিপ্ট ফাইল এবং আউটপুট ফাইল)
const ignoreFiles = ['combine.js', 'combiner.js', 'combined_part_1.txt', 'combined_part_2.txt', 'package-lock.json', 'package.json'];

// শুধু যে ফাইল টাইপগুলো আপনি যুক্ত করতে চান
const allowedExtensions = ['.php', '.js', '.css', '.json'];

function getAllFiles(dirPath, arrayOfFiles) {
    const files = fs.readdirSync(dirPath);
    arrayOfFiles = arrayOfFiles || [];

    files.forEach(function (file) {
        const fullPath = path.join(dirPath, file);
        if (fs.statSync(fullPath).isDirectory()) {
            if (!ignoreFolders.includes(file)) {
                arrayOfFiles = getAllFiles(fullPath, arrayOfFiles);
            }
        } else {
            // এক্সটেনশন চেক করার পাশাপাশি ফাইলটি ignoreFiles-এর লিস্টে আছে কিনা তাও চেক করা হচ্ছে
            if (allowedExtensions.includes(path.extname(file)) && !ignoreFiles.includes(file)) {
                arrayOfFiles.push(fullPath);
            }
        }
    });
    return arrayOfFiles;
}

const folderPath = './';
const allFiles = getAllFiles(folderPath);

const half = Math.ceil(allFiles.length / 2);
const part1Files = allFiles.slice(0, half);
const part2Files = allFiles.slice(half);

function writeCombinedFile(files, outputName) {
    let combinedContent = '';

    files.forEach(file => {
        const fileContent = fs.readFileSync(file, 'utf8');
        combinedContent += `\n\n/* ==========================================\n`;
        combinedContent += `   File: ${file}\n`;
        combinedContent += `   ========================================== */\n\n`;
        combinedContent += fileContent;
    });

    fs.writeFileSync(outputName, combinedContent);
    console.log(`✅ ${outputName} সফলভাবে তৈরি হয়েছে! (মোট ফাইল: ${files.length} টি)`);
}

writeCombinedFile(part1Files, 'combined_part_1.txt');
writeCombinedFile(part2Files, 'combined_part_2.txt');