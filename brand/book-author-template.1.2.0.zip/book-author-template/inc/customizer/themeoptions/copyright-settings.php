<?php
Kirki::add_section( 'copyright_section', array(
    'title'          => esc_html__( 'Copyright Settings', 'book-author-template' ),
    'panel'          => 'book_author_template_global_panel',
    'capability'     => 'edit_theme_options',
) );

Kirki::add_field( 'book_author_template_config', [
	'type'     => 'editor',
	'settings' => 'copyright_text',
	'label'    => esc_html__( 'Edit Copyright Text', 'book-author-template' ),
	'section'  => 'copyright_section',
	'default'  => wp_kses_post( 'Copyright <i class="rswpthemes-icon icon-copyright-solid" aria-hidden="true"></i> 2023. All rights reserved.', 'book-author-template' ),
	'transport' => 'postMessage',
    'js_vars'   => [
        [
            'element'  => '.site-copyright .site-info .site-copyright-text',
            'function' => 'html',
        ]
    ],
] );