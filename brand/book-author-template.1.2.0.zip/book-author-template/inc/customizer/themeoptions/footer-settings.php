<?php
Kirki::add_section( 'footer_section', array(
    'title'          => esc_html__( 'Footer Section', 'book-author-template' ),
    'panel'          => 'book_author_template_global_panel',
    'capability'     => 'edit_theme_options',
) );

Kirki::add_field( 'book_author_template_config', array(
    'type'        => 'custom',
    'settings'    => 'separator_before_footer_top_section',
    'label'       => '',
    'section'     => 'footer_section',
    'default'     => '<div class="settings-separator">'.esc_html__('Footer Top Section', 'book-author-template').'</div>',
) );

Kirki::add_field( 'book_author_template_config', [
	'type'        => 'toggle',
	'settings'    => 'show_footer_top_section',
	'label'       => esc_html__( 'Show Footer Top Section', 'book-author-template' ),
	'section'     => 'footer_section',
	'default'    => '1',
] );

Kirki::add_field( 'book_author_template_config', [
	'type'        => 'color',
	'settings'    => 'footer_top_bg_color',
	'label'       => __( 'Background Color', 'book-author-template' ),
	'section'     => 'footer_section',
	'default'     => '#1a1a1a',
	'transport'   => 'auto',
	'choices'	=> array(
		'alpha'	=> true,
	),
	'output' => array(
		array(
			'element'  => 'section.footer-content.footer-top-area',
			'property' => 'background-color',
		),
	),
	'active_callback'	=> function(){
		$showFooterTop = get_theme_mod('show_footer_top_section', true);
		if (true == $showFooterTop) {
			return true;
		}
		return false;
	}
] );

Kirki::add_field( 'book_author_template_config', [
	'type'        => 'color',
	'settings'    => 'footer_top_title_color',
	'label'       => __( 'Title Color', 'book-author-template' ),
	'section'     => 'footer_section',
	'default'     => 'rgb(255 255 255 / 50%)',
	'choices'	=> array(
		'alpha'	=> true,
	),
	'transport'   => 'auto',
	'output' => array(
		array(
			'element'  => 'section.footer-content.footer-top-area .widget-title.footer-title',
			'property' => 'color',
		),
	),
	'active_callback'	=> function(){
		$showFooterTop = get_theme_mod('show_footer_top_section', true);
		if (true == $showFooterTop) {
			return true;
		}
		return false;
	}
] );

Kirki::add_field( 'book_author_template_config', [
	'type'        => 'color',
	'settings'    => 'footer_top_title_border_color',
	'label'       => __( 'Title Border Color', 'book-author-template' ),
	'section'     => 'footer_section',
	'default'     => 'rgb(255 255 255 / 50%)',
	'transport'   => 'auto',
	'choices'	=> array(
		'alpha'	=> true,
	),
	'output' => array(
		array(
			'element'  => 'section.footer-content.footer-top-area .widget-title.footer-title',
			'property' => 'border-bottom-color',
		),
	),
	'active_callback'	=> function(){
		$showFooterTop = get_theme_mod('show_footer_top_section', true);
		if (true == $showFooterTop) {
			return true;
		}
		return false;
	}
] );

Kirki::add_field( 'book_author_template_config', [
	'type'        => 'color',
	'settings'    => 'footer_top_title_sep_color',
	'label'       => __( 'Title Separator Color', 'book-author-template' ),
	'section'     => 'footer_section',
	'default'     => 'rgb(255 255 255 / 50%)',
	'transport'   => 'auto',
	'choices'	=> array(
		'alpha'	=> true,
	),
	'output' => array(
		array(
			'element'  => 'section.footer-content.footer-top-area .widget-title.footer-title:before',
			'property' => 'background-color',
		),
	),
	'active_callback'	=> function(){
		$showFooterTop = get_theme_mod('show_footer_top_section', true);
		if (true == $showFooterTop) {
			return true;
		}
		return false;
	}
] );

Kirki::add_field( 'book_author_template_config', [
	'type'        => 'color',
	'settings'    => 'footer_top_text_color',
	'label'       => __( 'Text Color', 'book-author-template' ),
	'section'     => 'footer_section',
	'default'     => '#ffffff',
	'transport'   => 'auto',
	'choices'	=> array(
		'alpha'	=> true,
	),
	'output' => array(
		array(
			'element'  => 'section.footer-content.footer-top-area .widget p,section.footer-content.footer-top-area .widget,section.footer-content.footer-top-area .widget span,section.footer-content.footer-top-area .widget li,section.footer-content.footer-top-area .widget div,section.footer-content.footer-top-area .widget cite,section.footer-content.footer-top-area .widget span.rss-date,section.footer-content.footer-top-area .widget table',
			'property' => 'color',
		),
	),
	'active_callback'	=> function(){
		$showFooterTop = get_theme_mod('show_footer_top_section', true);
		if (true == $showFooterTop) {
			return true;
		}
		return false;
	}
] );

Kirki::add_field( 'book_author_template_config', [
	'type'        => 'color',
	'settings'    => 'footer_top_link_color',
	'label'       => __( 'Link Color', 'book-author-template' ),
	'section'     => 'footer_section',
	'default'     => '#ffffff',
	'transport'   => 'auto',
	'choices'	=> array(
		'alpha'	=> true,
	),
	'output' => array(
		array(
			'element'  => 'section.footer-content.footer-top-area .widget a:not(.rswpthemes-book-buy-now-button), section.footer-content.footer-top-area .rswpthemes-featured-book-area-inner .book-author h4, section.footer-content.footer-top-area ul.recent-post-widget li .recent-widget-content h2',
			'property' => 'color',
		),
	),
	'active_callback'	=> function(){
		$showFooterTop = get_theme_mod('show_footer_top_section', true);
		if (true == $showFooterTop) {
			return true;
		}
		return false;
	}
] );

Kirki::add_field( 'book_author_template_config', [
	'type'        => 'color',
	'settings'    => 'footer_top_menu_item_separator_color',
	'label'       => __( 'Menu Item Separator Color', 'book-author-template' ),
	'section'     => 'footer_section',
	'default'     => '#ffffff',
	'transport'   => 'auto',
	'choices'	=> array(
		'alpha'	=> true,
	),
	'output' => array(
		array(
			'element'  => 'section.footer-content.footer-top-area .widget.widget_nav_menu li, section.footer-content.footer-top-area .widget.widget_categories li',
			'property' => 'border-bottom-color',
		),
	),
	'active_callback'	=> function(){
		$showFooterTop = get_theme_mod('show_footer_top_section', true);
		if (true == $showFooterTop) {
			return true;
		}
		return false;
	}
] );


Kirki::add_field( 'book_author_template_config', array(
    'type'        => 'custom',
    'settings'    => 'separator_before_copyright_style',
    'label'       => '',
    'section'     => 'footer_section',
    'default'     => '<div class="settings-separator">'.esc_html__('Copyright Section Style', 'book-author-template').'</div>',
	'active_callback'	=> function(){
		$showFooterBottom = get_theme_mod('show_footer_bottom_section', true);
		if (true == $showFooterBottom) {
			return true;
		}
		return false;
	}
) );

Kirki::add_field( 'book_author_template_config', [
	'type'        => 'color',
	'settings'    => 'copyright_section_bg_color',
	'label'       => __( 'Copyright Background Color', 'book-author-template' ),
	'section'     => 'footer_section',
	'default'     => '#f4f4ec',
	'choices'     => [
		'alpha' => true,
	],
	'transport'   => 'auto',
	'output' => array(
		array(
			'element'  => '.site-copyright',
			'property' => 'background-color',
		),
	),
	'active_callback'	=> function(){
		$showFooterBottom = get_theme_mod('show_footer_bottom_section', true);
		if (true == $showFooterBottom) {
			return true;
		}
		return false;
	}
] );

Kirki::add_field( 'book_author_template_config', [
	'type'        => 'color',
	'settings'    => 'copyright_br_color',
	'label'       => __( 'Copyright Top Border Color', 'book-author-template' ),
	'section'     => 'footer_section',
	'default'     => '#f1f1f1',
	'choices'     => [
		'alpha' => true,
	],
	'transport'   => 'auto',
	'output' => array(
		array(
			'element'  => '.site-copyright',
			'property' => 'border-color',
		),
	),
	'active_callback'	=> function(){
		$showFooterBottom = get_theme_mod('show_footer_bottom_section', true);
		if (true == $showFooterBottom) {
			return true;
		}
		return false;
	}
] );

Kirki::add_field( 'book_author_template_config', [
	'type'        => 'color',
	'settings'    => 'copyright_text_color',
	'label'       => __( 'Copyright Text Color', 'book-author-template' ),
	'section'     => 'footer_section',
	'default'     => '#000000',
	'transport'   => 'auto',
	'output' => array(
		array(
			'element'  => '.site-copyright .site-info, .theme-by-wrapper .theme-by-inner',
			'property' => 'color',
		),
	),
	'active_callback'	=> function(){
		$showFooterBottom = get_theme_mod('show_footer_bottom_section', true);
		if (true == $showFooterBottom) {
			return true;
		}
		return false;
	}
] );

Kirki::add_field( 'book_author_template_config', [
	'type'        => 'color',
	'settings'    => 'copyright_text_link_color',
	'label'       => __( 'Copyright Text Link Color', 'book-author-template' ),
	'section'     => 'footer_section',
	'default'     => '#000000',
	'transport'   => 'auto',
	'output' => array(
		array(
			'element'  => '.site-copyright .site-info a, .theme-by-wrapper .theme-by-inner a',
			'property' => 'color',
		),
	),
	'active_callback'	=> function(){
		$showFooterBottom = get_theme_mod('show_footer_bottom_section', true);
		if (true == $showFooterBottom) {
			return true;
		}
		return false;
	}
] );