<?php
/**
 * About Me Customizer Settings
 */
Kirki::add_section( 'book_author_template_about_me_section', array(
    'title'          => esc_html__( 'About Section', 'book-author-template' ),
    'panel'          => 'book_author_template_frontpage',
    'active_callback'   => function(){
        $sections = get_theme_mod( 'book_author_template_sections' );
        if (is_array($sections) && in_array('about-author', $sections)) {
            return true;
        }
        return false;
    }
) );

do_action( 'book_author_template_about_section_option_before' );

Kirki::add_field( 'book_author_template_config', [
	'type'     => 'text',
	'settings' => 'about_welcome_text',
	'label'    => esc_html__( 'Welcome Text', 'book-author-template' ),
	'section'  => 'book_author_template_about_me_section',
	'default'  => esc_html__( 'Meet Author', 'book-author-template' ),
	'transport' => 'postMessage',
    'priority'  => 5,
    'js_vars'   => [
        [
            'element'  => '.about-me-content-wrapper .welcome-text',
            'function' => 'html',
        ]
    ],
] );

$booksQuery = get_posts(array(
	'numberposts'	=> -1,
	'post_type'   => 'page'
));

$booksLists = array('0' => '-----');

if (is_array($booksQuery) && !empty($booksQuery)) {
	foreach($booksQuery as $book):
		$booksLists[$book->post_name] = $book->post_title;
	endforeach;
}

wp_reset_postdata();

Kirki::add_field( 'book_author_template_config', array(
	'type'     => 'select',
	'settings' => 'about_me_page',
	'label'    => esc_html__( 'About Me Page', 'book-author-template' ),
	'section'  => 'book_author_template_about_me_section',
	'transport' => 'refresh',
	'choices'     => $booksLists,
    'priority'  => 10,
) );

Kirki::add_field( 'book_author_template_config', [
    'type'        => 'toggle',
    'settings'    => 'show_about_button',
    'label'       => esc_html__( 'Show About Button', 'book-author-template' ),
    'section'     => 'book_author_template_about_me_section',
    'default'     => '1',
    'priority'  => 15,
] );

Kirki::add_field( 'book_author_template_config', [
	'type'     => 'text',
	'settings' => 'about_button_text',
	'label'    => esc_html__( 'Button Text', 'book-author-template' ),
	'section'  => 'book_author_template_about_me_section',
	'default'  => esc_html__( 'About Me', 'book-author-template' ),
	'transport' => 'postMessage',
    'priority'  => 20,
    'js_vars'   => [
        [
            'element'  => '.about-me-content-wrapper .about-me-button a',
            'function' => 'html',
        ]
    ],
    'active_callback' => [
        [
            'setting'  => 'show_about_button',
            'operator' => '==',
            'value'    => '1',
        ],
    ],
] );

Kirki::add_field( 'book_author_template_config', [
	'type'     => 'text',
	'settings' => 'about_button_link',
	'label'    => esc_html__( 'Button Link', 'book-author-template' ),
	'section'  => 'book_author_template_about_me_section',
	'default'  => '#',
	'transport' => 'refresh',
    'priority'  => 25,
    'active_callback' => [
        [
            'setting'  => 'show_about_button',
            'operator' => '==',
            'value'    => '1',
        ],
    ],
] );


Kirki::add_field( 'book_author_template_config', [
    'type'        => 'toggle',
    'settings'    => 'show_about_section_s_l',
    'label'       => esc_html__( 'Show Social Links', 'book-author-template' ),
    'section'     => 'book_author_template_about_me_section',
    'default'     => '1',
    'priority'  => 30,
] );

Kirki::add_field( 'book_author_template_config', [
	'type'     => 'text',
	'settings' => 'about_follow_me_text',
	'label'    => esc_html__( 'Follow Me Text', 'book-author-template' ),
	'section'  => 'book_author_template_about_me_section',
	'default'  => esc_html__( 'Follow Me', 'book-author-template' ),
	'transport' => 'postMessage',
    'priority'  => 35,
    'js_vars'   => [
        [
            'element'  => '.about-me-content-wrapper .follow-me-icons .text span',
            'function' => 'html',
        ]
    ],
    'active_callback' => [
        [
            'setting'  => 'show_about_section_social_links',
            'operator' => '==',
            'value'    => '1',
        ],
    ],
] );

do_action( 'book_author_template_about_section_option_after' );