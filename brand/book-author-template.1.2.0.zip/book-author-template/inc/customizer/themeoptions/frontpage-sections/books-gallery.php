<?php
Kirki::add_section( 'book_author_template_all_books_section', array(
    'title'          => esc_html__( 'Books Gallery', 'book-author-template' ),
    'panel'          => 'book_author_template_frontpage',
    'active_callback'   => function(){
        $sections = get_theme_mod( 'book_author_template_sections' );
        if (is_array($sections) && in_array('books-gallery', $sections)) {
            return true;
        }
        return false;
    }
) );
do_action( 'book_author_template_books_gallery_option_before' );
Kirki::add_field( 'book_author_template_config', [
	'type'     => 'text',
	'settings' => 'book_author_template_all_books_sec_sub_heading',
	'label'    => esc_html__( 'Section Sub Heading', 'book-author-template' ),
	'section'  => 'book_author_template_all_books_section',
	'default'  => esc_html__( 'Author’s All Book', 'book-author-template' ),
	'transport' => 'postMessage',
    'priority'  => 5,
    'js_vars'   => [
        [
            'element'  => '.section-title-wrapper .section-title-label',
            'function' => 'html',
        ]
    ],
] );

Kirki::add_field( 'book_author_template_config', [
	'type'     => 'textarea',
	'settings' => 'book_author_template_all_books_sec_heading',
	'label'    => esc_html__( 'Section Heading', 'book-author-template' ),
	'section'  => 'book_author_template_all_books_section',
	'default'  => esc_html__( 'Discover the Best of Taylor Jenking Reid', 'book-author-template' ),
	'transport' => 'postMessage',
    'priority'  => 10,
    'js_vars'   => [
        [
            'element'  => '.section-title-wrapper .section-title',
            'function' => 'html',
        ]
    ],
] );

Kirki::add_field( 'book_author_template_config', [
	'type'     => 'textarea',
	'settings' => 'book_author_template_all_books_sec_desc',
	'label'    => esc_html__( 'Section Description', 'book-author-template' ),
	'section'  => 'book_author_template_all_books_section',
	'default'  => esc_html__( 'has written an extensive collection of books spanning multiple genres. Their captivating storytelling and richly imagined worlds feature complex characters and engrossing plots that keep', 'book-author-template' ),
	'transport' => 'postMessage',
    'priority'  => 15,
    'js_vars'   => [
        [
            'element'  => '.section-description-wrapper p',
            'function' => 'html',
        ]
    ],
] );
do_action('book_author_template_books_gallery_option_after');