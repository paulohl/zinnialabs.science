<?php
Kirki::add_section( 'book_author_template_eamil_signup_section', array(
    'title'          => esc_html__( 'Signup From', 'book-author-template' ),
    'panel'          => 'book_author_template_frontpage',
    'active_callback'   => function(){
        $sections = get_theme_mod( 'book_author_template_sections' );
        if (is_array($sections) && in_array('signup-form', $sections)) {
            return true;
        }
        return false;
    }
) );

do_action('book_author_template_signup_form_option_before');

Kirki::add_field( 'book_author_template_config', [
	'type'     => 'text',
	'settings' => 'book_author_template_email_signup_heading',
	'label'    => esc_html__( 'Section Sub Heading', 'book-author-template' ),
	'section'  => 'book_author_template_eamil_signup_section',
	'default'  => esc_html__( 'Want To Hear More From Taylor?', 'book-author-template' ),
	'transport' => 'postMessage',
	'priority'	=> 5,
    'js_vars'   => [
        [
            'element'  => '.email-signup-content-wrapper h4',
            'function' => 'html',
        ]
    ],
] );

Kirki::add_field( 'book_author_template_config', [
	'type'     => 'textarea',
	'settings' => 'book_author_template_email_signup_sub_heading',
	'label'    => esc_html__( 'Section Heading', 'book-author-template' ),
	'section'  => 'book_author_template_eamil_signup_section',
	'default'  => esc_html__( 'Sign up  to receive news,updates, and exclusive content.', 'book-author-template' ),
	'transport' => 'postMessage',
	'priority'	=> 10,
    'js_vars'   => [
        [
            'element'  => '.email-signup-content-wrapper p',
            'function' => 'html',
        ]
    ],
] );

Kirki::add_field( 'book_author_template_config', [
	'type'     => 'textarea',
	'settings' => 'book_author_template_email_signup_shortcode',
	'label'    => esc_html__( 'Form Shortcode', 'book-author-template' ),
	'section'  => 'book_author_template_eamil_signup_section',
	'default'  => '',
	'transport' => 'refresh',
	'priority'	=> 15,
] );

do_action( 'book_author_template_signup_form_option_after' );