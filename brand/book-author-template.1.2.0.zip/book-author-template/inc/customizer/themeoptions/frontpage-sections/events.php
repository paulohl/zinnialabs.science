<?php
Kirki::add_section( 'book_author_template_book_events_section', array(
    'title'          => esc_html__( 'Events', 'book-author-template' ),
    'active_callback'   => function(){
        $sections = get_theme_mod( 'book_author_template_sections' );
        if (is_array($sections) && in_array('events', $sections)) {
            return true;
        }
        return false;
    }
) );

Kirki::add_field( 'book_author_template_config', array(
	'type'     => 'repeater',
	'settings' => 'book_author_template_events',
	'label'    => esc_html__( 'Events', 'book-author-template' ),
	'section'  => 'book_author_template_book_events_section',
	'transport' => 'postMessage',
	'button_label' => esc_html__( 'Add New Event', 'book-author-template' ),
	'row_label'    => [
		'type'  => 'field',
		'value' => esc_html__( 'Book', 'book-author-template' ),
		'field' => 'book_event_slug',
	],
	'choices' => [
		'limit' => 1,
	],
	'fields'   => array(
		'book_event_slug'   => array(
			'type'        => 'select',
			'label'       => esc_html__( 'Select Event', 'book-author-template' ),
			'choices'     => book_author_template_get_posts_for_customizer('event'),
		),
	)
) );