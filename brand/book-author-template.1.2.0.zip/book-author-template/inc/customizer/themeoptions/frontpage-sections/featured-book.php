<?php
Kirki::add_section( 'book_author_template_featured_books_section', array(
    'title'          => esc_html__( 'Featured Books', 'book-author-template' ),
    'panel'          => 'book_author_template_frontpage',
    'active_callback'   => function(){
        $sections = get_theme_mod( 'book_author_template_sections' );
        if (is_array($sections) && in_array('featured-books', $sections)) {
            return true;
        }
        return false;
    }
) );

do_action( 'book_author_template_featured_book_option_before' );

$rowLimit = 1;
if (class_exists('Book_Author_Template_Pro')) {
	$rowLimit = 20;
}

Kirki::add_field( 'book_author_template_config', array(
	'type'     => 'repeater',
	'settings' => 'featured_books',
	'label'    => esc_html__( 'Featured Books', 'book-author-template' ),
	'section'  => 'book_author_template_featured_books_section',
	'transport' => 'postMessage',
	'priority' => 5,
	'button_label' => esc_html__( 'Add New Book', 'book-author-template' ),
	'row_label'    => [
		'type'  => 'field',
		'value' => esc_html__( 'Book', 'book-author-template' ),
		'field' => 'book_slug',
	],
	'choices' => [
		'limit' => $rowLimit,
	],
	'fields'   => array(
		'book_slug'   => array(
			'type'        => 'select',
			'label'       => esc_html__( 'Select Book', 'book-author-template' ),
			'choices'     => book_author_template_get_posts_for_customizer('book'),
		),
		'book_label'   => array(
			'type'        => 'text',
			'label'       => esc_html__( 'Book Label', 'book-author-template' ),
			'default'     => esc_html__( 'Best seller', 'book-author-template' ),
		),
	)
) );

do_action( 'book_author_template_featured_book_option_after' );