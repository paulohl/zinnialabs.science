<?php
Kirki::add_section( 'frontpage_sections', array(
    'title'          => esc_html__( 'Front Page Sections', 'book-author-template' ),
    'panel'          => 'book_author_template_frontpage',
    'capability'     => 'edit_theme_options',
    'priority'		=> 10,
) );

Kirki::add_field( 'book_author_template_config', array(
	'type'     => 'sortable',
	'settings' => 'book_author_template_sections',
	'label'    => esc_html__( 'Front Page Sections', 'book-author-template' ),
	'section'  => 'frontpage_sections',
	'default'  => '',
	'choices'  => [
		'featured-books' => esc_html__( 'Featured Books', 'book-author-template' ),
		'about-author' => esc_html__( 'About Author', 'book-author-template' ),
		'signup-form' => esc_html__( 'Email Sign Up Form', 'book-author-template' ),
		'books-gallery' => esc_html__( 'Books Gallery', 'book-author-template' ),
		'testimonials' => esc_html__( 'Testimonials', 'book-author-template' ),
		'latest-posts' => esc_html__( 'Latest Posts', 'book-author-template' ),
		'events' => esc_html__( 'Events', 'book-author-template' ),
		'instagram' => esc_html__( 'Instagram', 'book-author-template' ),
	],
));