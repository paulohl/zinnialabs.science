<?php
Kirki::add_section( 'book_author_template_testimonial_section', array(
    'title'          => esc_html__( 'Testimonials', 'book-author-template' ),
    'panel'          => 'book_author_template_frontpage',
    'active_callback'   => function(){
        $sections = get_theme_mod( 'book_author_template_sections' );
        if (is_array($sections) && in_array('testimonials', $sections)) {
            return true;
        }
        return false;
    }
) );

Kirki::add_field( 'book_author_template_config', [
    'type'     => 'text',
    'settings' => 'book_author_template_testimonial_section_sub_heading',
    'label'    => esc_html__( 'Section Sub Heading', 'book-author-template' ),
    'section'  => 'book_author_template_testimonial_section',
    'default'  => esc_html__( 'Testimonials', 'book-author-template' ),
    'transport' => 'postMessage',
    'js_vars'   => [
        [
            'element'  => '.customer-reveiw-section-title h4',
            'function' => 'html',
        ]
    ],
] );

Kirki::add_field( 'book_author_template_config', [
    'type'     => 'textarea',
    'settings' => 'book_author_template_testimonial_section_heading',
    'label'    => esc_html__( 'Section Heading', 'book-author-template' ),
    'section'  => 'book_author_template_testimonial_section',
    'default'  => esc_html__( 'Words From Our Happy Readers.', 'book-author-template' ),
    'transport' => 'postMessage',
    'js_vars'   => [
        [
            'element'  => '.customer-reveiw-section-title h2',
            'function' => 'html',
        ]
    ],
] );