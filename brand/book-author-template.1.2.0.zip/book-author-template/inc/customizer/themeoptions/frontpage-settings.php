<?php
Kirki::add_panel( 'book_author_template_frontpage', array(
    'priority'    => 10,
    'title'       => esc_html__( 'Front Page Template', 'book-author-template' ),
) );
require get_theme_file_path('inc/customizer/themeoptions/frontpage-sections/frontpage-sections.php');
require get_theme_file_path('inc/customizer/themeoptions/frontpage-sections/featured-book.php');
require get_theme_file_path('inc/customizer/themeoptions/frontpage-sections/about-author.php');
require get_theme_file_path('inc/customizer/themeoptions/frontpage-sections/email-signup.php');
require get_theme_file_path('inc/customizer/themeoptions/frontpage-sections/books-gallery.php');
require get_theme_file_path('inc/customizer/themeoptions/frontpage-sections/testimonials.php');
require get_theme_file_path('inc/customizer/themeoptions/frontpage-sections/events.php');