<?php
Kirki::add_section( 'book_author_template_theme_header_section', array(
    'title'          => esc_html__( 'Header Settings', 'book-author-template' ),
    'panel'          => 'book_author_template_global_panel',
    'priority'      => 10,
) );

Kirki::add_field( 'book_author_template_config', [
    'type'        => 'color',
    'settings'    => 'header_bg_color',
    'label'       => __( 'Background Color', 'book-author-template' ),
    'section'     => 'book_author_template_theme_header_section',
    'default'     => '#ffffff',
    'transport'   => 'auto',
    'priority'  => 3,
    'output' => array(
        array(
            'element'  => 'header#masthead',
            'property' => 'background-color',
        ),
    ),
] );

Kirki::add_field( 'book_author_template_config', [
    'type'        => 'typography',
    'settings'    => 'header_title_typography',
    'label'       => esc_html__( 'Site Title Typography', 'book-author-template' ),
    'section'     => 'book_author_template_theme_header_section',
    'default'     => [
        'font-family'    => 'Roboto',
        'variant'        => '700',
        'font-size'      => '1.3rem',
        'line-height'    => '1.6',
        'letter-spacing' => '0px',
        'color'          => '#000000',
        'text-transform' => 'none',
    ],
    'transport'   => 'auto',
    'priority'      => 6,
    'output'      => [
        [
            'element' => '.site-branding .site-title a',
        ],
    ],
] );

Kirki::add_field( 'book_author_template_config', [
    'type'        => 'typography',
    'settings'    => 'header_desc_typography',
    'label'       => esc_html__( 'Site Description Typography', 'book-author-template' ),
    'section'     => 'book_author_template_theme_header_section',
    'default'     => [
        'font-family'    => 'Roboto',
        'variant'        => 'regular',
        'font-size'      => '1rem',
        'line-height'    => '1.4',
        'letter-spacing' => '0px',
        'color'          => '#000000',
        'text-transform' => 'none',
    ],
    'transport'   => 'auto',
    'priority'      => 7,
    'output'      => [
        [
            'element' => '.site-branding p.site-description',
        ],
    ],
] );

Kirki::add_field( 'book_author_template_config', [
    'type'        => 'typography',
    'settings'    => 'header_menu_typography',
    'label'       => esc_html__( 'Menu Typography', 'book-author-template' ),
    'section'     => 'book_author_template_theme_header_section',
    'default'     => [
        'font-family'    => 'Roboto',
        'variant'        => 'regular',
        'font-size'      => '1rem',
        'line-height'    => '1.6',
        'letter-spacing' => '0px',
        'color'          => '#000000',
        'text-transform' => 'none',
    ],
    'transport'   => 'auto',
    'priority'  => 8,
    'output'      => [
        [
            'element' => '#cssmenu>ul>li>a',
        ],
    ],
] );


Kirki::add_field( 'book_author_template_config', [
    'type'        => 'color',
    'settings'    => 'header_menu_hover_color',
    'label'       => __( 'Menu Hover Color', 'book-author-template' ),
    'section'     => 'book_author_template_theme_header_section',
    'default'     => '#228B22',
    'transport'   => 'auto',
    'priority'      => 9,
    'output' => array(
        array(
            'element'  => '#cssmenu>ul>li:hover>a',
            'property' => 'color',
        ),
    ),
] );

Kirki::add_field( 'book_author_template_config', [
    'type'        => 'color',
    'settings'    => 'header_sub_menu_hover_color',
    'label'       => __( 'Sub Menu Hover Color', 'book-author-template' ),
    'section'     => 'book_author_template_theme_header_section',
    'default'     => '#228B22',
    'transport'   => 'auto',
    'priority'    => 10,
    'output' => array(
        array(
            'element'  => '#cssmenu ul ul li:hover>a, #cssmenu ul ul li a:hover',
            'property' => 'color',
        ),
    ),
] );