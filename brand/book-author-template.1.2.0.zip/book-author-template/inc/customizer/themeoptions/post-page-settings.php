<?php
/**
 * Blog single content customization
 */
Kirki::add_section( 'post_page_section', array(
    'title'          => esc_html__( 'Post Page Settings', 'book-author-template' ),
    'description'    => esc_html__( 'Customize The Looks of Post Page', 'book-author-template' ),
    'panel'          => 'book_author_template_global_panel',
) );
Kirki::add_field( 'book_author_template_config', [
    'type'        => 'toggle',
    'settings'    => 'show_single_post_category',
    'label'       => esc_html__( 'Show Post Category', 'book-author-template' ),
    'section'     => 'post_page_section',
    'default'     => '1',
] );
Kirki::add_field( 'book_author_template_config', [
    'type'        => 'toggle',
    'settings'    => 'show_single_post_author',
    'label'       => esc_html__( 'Show Post Author', 'book-author-template' ),
    'section'     => 'post_page_section',
    'default'     => '1',
] );
Kirki::add_field( 'book_author_template_config', [
    'type'        => 'toggle',
    'settings'    => 'show_single_post_thumbnail',
    'label'       => esc_html__( 'Show Post Thumbnail', 'book-author-template' ),
    'section'     => 'post_page_section',
    'default'     => '1',

] );
Kirki::add_field( 'book_author_template_config', [
    'type'        => 'toggle',
    'settings'    => 'show_single_post_title',
    'label'       => esc_html__( 'Show Post Title', 'book-author-template' ),
    'section'     => 'post_page_section',
    'default'     => '1',
] );
Kirki::add_field( 'book_author_template_config', [
    'type'        => 'toggle',
    'settings'    => 'show_single_post_date',
    'label'       => esc_html__( 'Show Post Date', 'book-author-template' ),
    'section'     => 'post_page_section',
    'default'     => '1',

] );
Kirki::add_field( 'book_author_template_config', [
    'type'        => 'toggle',
    'settings'    => 'show_single_post_comments',
    'label'       => esc_html__( 'Show Post Comments', 'book-author-template' ),
    'section'     => 'post_page_section',
    'default'     => '1',

] );
Kirki::add_field( 'book_author_template_config', [
    'type'        => 'toggle',
    'settings'    => 'show_single_post_tags',
    'label'       => esc_html__( 'Show Post Tags', 'book-author-template' ),
    'section'     => 'post_page_section',
    'default'     => '1',

] );
Kirki::add_field( 'book_author_template_config', [
    'type'        => 'toggle',
    'settings'    => 'show_post_author_box',
    'label'       => esc_html__( 'Show Post Author Box', 'book-author-template' ),
    'section'     => 'post_page_section',
    'default'     => '1',
] );
Kirki::add_field( 'book_author_template_config', [
    'type'        => 'toggle',
    'settings'    => 'show_recommend_posts',
    'label'       => esc_html__( 'Show Recommend Posts', 'book-author-template' ),
    'section'     => 'post_page_section',
    'default'     => '1',
] );
Kirki::add_field( 'book_author_template_config', [
    'type'        => 'toggle',
    'settings'    => 'show_post_navigation',
    'label'       => esc_html__( 'Show Post Navigation', 'book-author-template' ),
    'section'     => 'post_page_section',
    'default'     => '1',
] );

Kirki::add_field( 'book_author_template_config', [
    'type'        => 'typography',
    'settings'    => 'single_post_title_typography',
    'label'       => esc_html__( 'Post Title Typography', 'book-author-template' ),
    'section'     => 'post_page_section',
    'default'     => [
        'font-family'    => 'Roboto',
        'variant'        => 'bold',
        'font-size'      => '2.25rem',
        'line-height'    => '1.6',
        'letter-spacing' => '0px',
        'color'          => '#000000',
        'text-transform' => 'none',
        'text-align'     => 'left',
    ],
    'transport'   => 'auto',
    'output'      => [
        [
            'element' => '.post-details-page .book-author-template-standard-post__post-title h1.single-post-title',
        ],
    ],
] );

do_action('bab_post_page_settings');