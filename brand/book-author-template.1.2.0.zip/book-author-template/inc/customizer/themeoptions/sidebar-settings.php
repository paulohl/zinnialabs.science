<?php
/*Blog Page Settings*/

Kirki::add_section( 'sidebar_settings_section', array(
    'title'          => esc_html__( 'Sidebar Settings', 'book-author-template' ),
    'description'          => esc_html__( 'Control Sidebar Of Your Website', 'book-author-template' ),
    'panel'          => 'book_author_template_global_panel',
) );

Kirki::add_field( 'book_author_template_config', [
	'type'        => 'select',
	'settings'    => 'blog_page_sidebar',
	'label'       => esc_html__( 'Blog Page Sidebar', 'book-author-template' ),
	'section'     => 'sidebar_settings_section',
	'default'     => 'right',
	'multiple'    => 1,
	'choices'     => [
		'left' => esc_html__( 'left Sidebar', 'book-author-template' ),
		'right' => esc_html__( 'Right Sidebar', 'book-author-template' ),
		'no' => esc_html__( 'No Sidebar', 'book-author-template' ),
		'both' => esc_html__( 'Left & Right Sidebar', 'book-author-template' ),
	],
] );

Kirki::add_field( 'book_author_template_config', [
	'type'        => 'select',
	'settings'    => 'blog_page_post_column',
	'label'       => esc_html__( 'Post Column', 'book-author-template' ),
	'section'     => 'sidebar_settings_section',
	'default'    => '2',
	'choices' => [
			'4' => __( '4 Colmun', 'book-author-template' ),
			'3' => __( '3 Column', 'book-author-template' ),
			'2' => __( '2 Column', 'book-author-template' ),
			'1' => __( 'Single Column', 'book-author-template' ),
		],
] );

Kirki::add_field( 'rs_personal_blog_config', array(
    'type'        => 'custom',
    'settings'    => 'sep_after_blog_post_column',
    'label'       => '',
    'section'     => 'sidebar_settings_section',
    'default'     => '<hr>',
) );

Kirki::add_field( 'book_author_template_config', [
	'type'        => 'select',
	'settings'    => 'archive_page_sidebar',
	'label'       => esc_html__( 'Archive Page Sidebar', 'book-author-template' ),
	'section'     => 'sidebar_settings_section',
	'default'     => 'right',
	'multiple'    => 1,
	'choices'     => [
		'left' => esc_html__( 'left Sidebar', 'book-author-template' ),
		'right' => esc_html__( 'Right Sidebar', 'book-author-template' ),
		'no' => esc_html__( 'No Sidebar', 'book-author-template' ),
		'both' => esc_html__( 'Left & Right Sidebar', 'book-author-template' ),
	],
] );

Kirki::add_field( 'book_author_template_config', [
	'type'        => 'select',
	'settings'    => 'archive_page_post_column',
	'label'       => esc_html__( 'Post Column', 'book-author-template' ),
	'section'     => 'sidebar_settings_section',
	'default'    => '2',
	'choices' => [
			'4' => __( '4 Colmun', 'book-author-template' ),
			'3' => __( '3 Column', 'book-author-template' ),
			'2' => __( '2 Column', 'book-author-template' ),
			'1' => __( 'Single Column', 'book-author-template' ),
		],
] );

Kirki::add_field( 'rs_personal_blog_config', array(
    'type'        => 'custom',
    'settings'    => 'sep_after_archive_post_column',
    'label'       => '',
    'section'     => 'sidebar_settings_section',
    'default'     => '<hr>',
) );

Kirki::add_field( 'book_author_template_config', [
	'type'        => 'select',
	'settings'    => 'page_sidebar',
	'label'       => esc_html__( 'Page Sidebar', 'book-author-template' ),
	'section'     => 'sidebar_settings_section',
	'default'     => 'right',
	'multiple'    => 1,
	'choices'     => [
		'left' => esc_html__( 'left Sidebar', 'book-author-template' ),
		'right' => esc_html__( 'Right Sidebar', 'book-author-template' ),
		'no' => esc_html__( 'No Sidebar', 'book-author-template' ),
		'both' => esc_html__( 'Left & Right Sidebar', 'book-author-template' ),
	],
] );
Kirki::add_field( 'book_author_template_config', [
	'type'        => 'select',
	'settings'    => 'post_sidebar',
	'label'       => esc_html__( 'Post Sidebar', 'book-author-template' ),
	'section'     => 'sidebar_settings_section',
	'default'     => 'right',
	'multiple'    => 1,
	'choices'     => [
		'left' => esc_html__( 'left Sidebar', 'book-author-template' ),
		'right' => esc_html__( 'Right Sidebar', 'book-author-template' ),
		'no' => esc_html__( 'No Sidebar', 'book-author-template' ),
		'both' => esc_html__( 'Left & Right Sidebar', 'book-author-template' ),
	],
] );
Kirki::add_field( 'rs_personal_blog_config', array(
    'type'        => 'custom',
    'settings'    => 'sep_after_post_sidebar',
    'label'       => '',
    'section'     => 'sidebar_settings_section',
    'default'     => '<hr>',
) );
Kirki::add_field( 'book_author_template_config', [
	'type'        => 'select',
	'settings'    => 'search_page_sidebar',
	'label'       => esc_html__( 'Search Page Sidebar', 'book-author-template' ),
	'section'     => 'sidebar_settings_section',
	'default'     => 'right',
	'choices'     => [
		'left' => esc_html__( 'left Sidebar', 'book-author-template' ),
		'right' => esc_html__( 'Right Sidebar', 'book-author-template' ),
		'no' => esc_html__( 'No Sidebar', 'book-author-template' ),
		'both' => esc_html__( 'Left & Right Sidebar', 'book-author-template' ),
	],
] );

Kirki::add_field( 'book_author_template_config', [
	'type'        => 'select',
	'settings'    => 'search_page_post_column',
	'label'       => esc_html__( 'Post Column', 'book-author-template' ),
	'section'     => 'sidebar_settings_section',
	'default'    => '2',
	'choices' => [
			'4' => __( '4 Colmun', 'book-author-template' ),
			'3' => __( '3 Column', 'book-author-template' ),
			'2' => __( '2 Column', 'book-author-template' ),
			'1' => __( 'Single Column', 'book-author-template' ),
		],
] );

Kirki::add_field( 'book_author_template_config', [
	'type'        => 'select',
	'settings'    => 'event_page_sidebar',
	'label'       => esc_html__( 'Event Page Sidebar', 'book-author-template' ),
	'section'     => 'sidebar_settings_section',
	'default'     => 'no',
	'choices'     => [
		'left' => esc_html__( 'left Sidebar', 'book-author-template' ),
		'right' => esc_html__( 'Right Sidebar', 'book-author-template' ),
		'no' => esc_html__( 'No Sidebar', 'book-author-template' ),
		'both' => esc_html__( 'Left & Right Sidebar', 'book-author-template' ),
	],
] );

Kirki::add_field( 'book_author_template_config', [
	'type'        => 'select',
	'settings'    => 'event_single_page_sidebar',
	'label'       => esc_html__( 'Event Single Page Sidebar', 'book-author-template' ),
	'section'     => 'sidebar_settings_section',
	'default'     => 'no',
	'choices'     => [
		'left' => esc_html__( 'left Sidebar', 'book-author-template' ),
		'right' => esc_html__( 'Right Sidebar', 'book-author-template' ),
		'no' => esc_html__( 'No Sidebar', 'book-author-template' ),
		'both' => esc_html__( 'Left & Right Sidebar', 'book-author-template' ),
	],
] );
