<?php
/**
 * Theme Color Settings
 *
 * @package Book Author Template
 */

// Global Heading Color
Kirki::add_field( 'book_author_template_config', [
	'type'        => 'color',
	'settings'    => 'global_heading_color',
	'label'       => __( 'Global Heading Color', 'book-author-template' ),
	'section'     => 'colors',
	'default'     => '#000000',
	'transport'   => 'postMessage',
] );

// Global Body Color
Kirki::add_field( 'book_author_template_config', [
	'type'        => 'color',
	'settings'    => 'global_body_color',
	'label'       => __( 'Global Body Color', 'book-author-template' ),
	'section'     => 'colors',
	'default'     => '#000000',
	'transport'   => 'postMessage',
] );

// Global Background Color 1 (Primary/White)
Kirki::add_field( 'book_author_template_config', [
	'type'        => 'color',
	'settings'    => 'global_bg_color_1',
	'label'       => __( 'Global Background Color 1', 'book-author-template' ),
	'description' => __( 'Used for main content backgrounds (usually white).', 'book-author-template' ),
	'section'     => 'colors',
	'default'     => '#ffffff',
	'transport'   => 'postMessage',
] );

// Global Background Color 2 (Secondary/Light Gray)
Kirki::add_field( 'book_author_template_config', [
	'type'        => 'color',
	'settings'    => 'global_bg_color_2',
	'label'       => __( 'Global Background Color 2', 'book-author-template' ),
	'description' => __( 'Used for secondary sections (usually light gray).', 'book-author-template' ),
	'section'     => 'colors',
	'default'     => '#f1f1f1',
	'transport'   => 'postMessage',
] );

// Global Background Color 3 (Accent/Brand Color)
Kirki::add_field( 'book_author_template_config', [
	'type'        => 'color',
	'settings'    => 'global_bg_color_3',
	'label'       => __( 'Global Background Color 3', 'book-author-template' ),
	'description' => __( 'Used for buttons, links, and accents.', 'book-author-template' ),
	'section'     => 'colors',
	'default'     => '#228B22',
	'transport'   => 'postMessage',
] );
