<?php
/**
 * Typography Settings
 *
 * @package Book Author Template
 */

// Global Heading Font
Kirki::add_field( 'book_author_template_config', [
	'type'        => 'typography',
	'settings'    => 'global_heading_font',
	'label'       => __( 'Global Heading Font', 'book-author-template' ),
	'section'     => 'typography',
	'default'     => [
		'font-family'    => 'Roboto',
		'variant'        => '700',
	],
	'priority'    => 10,
	'transport'   => 'postMessage',
	'output'      => [
		[
			'element' => 'h1, h2, h3, h4, h5, h6, .h1, .h2, .h3, .h4, .h5, .h6',
		],
	],
] );

// Global Body Font
Kirki::add_field( 'book_author_template_config', [
	'type'        => 'typography',
	'settings'    => 'global_body_font',
	'label'       => __( 'Global Body Font', 'book-author-template' ),
	'section'     => 'typography',
	'default'     => [
		'font-family'    => 'Roboto',
		'variant'        => 'regular',
	],
	'priority'    => 10,
	'transport'   => 'postMessage',
	'output'      => [
		[
			'element' => 'body, button, input, select, optgroup, textarea',
		],
	],
] );
