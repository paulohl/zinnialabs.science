<?php
/**
 * Enqueue scripts and styles.
 */
function book_author_template_scripts() {
	$isBookSliderActivated = get_theme_mod('books_slider_on_off', false);

	wp_enqueue_style( 'book-author-template-style', get_stylesheet_uri() );

	$template_parts = get_theme_mod( 'book_author_template_sections' );
	if (is_page_template('frontpage.php')) {
		if (is_array($template_parts) && in_array('featured-books', $template_parts)) {
			wp_enqueue_style( 'featured-book-section', esc_url(get_theme_file_uri( 'assets/css/featured-book-section.css' )) );
			wp_enqueue_style( 'email-signup-section', esc_url(get_theme_file_uri( 'assets/css/email-signup.css' )) );
		}
		if (is_array($template_parts) && in_array('about-author', $template_parts)) {
			wp_enqueue_style( 'about-author-section', esc_url(get_theme_file_uri( 'assets/css/about-author-section.css' )) );
		}
		if (is_array($template_parts) && in_array('books-gallery', $template_parts)) {
			wp_enqueue_style( 'books-gallery', esc_url(get_theme_file_uri( 'assets/css/books-gallery-section.css' )) );
		}
		if (is_array($template_parts) && in_array('testimonials', $template_parts)) {
			wp_enqueue_style('slick');
			wp_enqueue_script('slick');
			wp_enqueue_script('rswpbs-review-slider-script');
			wp_enqueue_style('rswpbs-review-slider-style');
		}
		if (is_array($template_parts) && in_array('book-events', $template_parts)) {
			wp_enqueue_style( 'book-events-section', esc_url(get_theme_file_uri( 'assets/css/book-events.css' )) );
		}
	}

	wp_enqueue_style( 'rswpthemes-icons', get_theme_file_uri('assets/icons/icons.css') );

	if (is_post_type_archive( 'event' ) || is_singular( 'event' )) {
		wp_enqueue_style( 'book-events-section', esc_url(get_theme_file_uri( 'assets/css/book-events.css' )) );
	}

	if ( function_exists( 'is_woocommerce' ) && ( is_woocommerce() || is_cart() || is_checkout() || is_account_page() ) ) {
		wp_enqueue_style( 'woocommerce-style', esc_url(get_theme_file_uri( 'assets/css/woocommerce-style.css' )) );
	}
	$headerContainerSize = '1170';
	$banner_height = 200;
	$headerContainerSize = get_theme_mod('header_container_custom_size', '1170');
	$banner_height = get_theme_mod('page_banner_custom_height', 200);
	$headerBgColor = get_theme_mod('header_bg_color', '#000000');
	$inline_style_data = '
		@media (min-width: 1200px) {
			#masthead .container.container-custom-size{
				width: '.$headerContainerSize.'px;
				max-width: '.$headerContainerSize.'px;
			}
		}
		.page-header-area.banner-custom-height{
			height: '.$banner_height.'px;
		}
		header.site-header.header-one{
			background-color: '.$headerBgColor.';
		}
	';
	wp_add_inline_style('book-author-template-style', $inline_style_data);
	$isMasonryActivated = get_theme_mod('active_masonry_layout', true);
	if (true == $isMasonryActivated) :
		wp_enqueue_script( 'imagesloaded', esc_url( get_template_directory_uri() ) . '/assets/js/imagesloaded.pkgd.min.js', array( 'jquery' ), '1.0', true );
		wp_enqueue_script( 'masonry' );
	endif;
	wp_enqueue_script( 'book-author-template-menu', esc_url( get_template_directory_uri() ) . '/assets/js/menu.js', array( 'jquery' ), '1.0', true );
	if (true == $isBookSliderActivated) {
		wp_enqueue_script( 'slick', esc_url( get_template_directory_uri() ) . '/assets/js/slick.js', array( 'jquery' ), '1.0', true );
		wp_enqueue_script( 'book-author-template-slider', esc_url( get_template_directory_uri() ) . '/assets/js/slider.js', array( 'jquery', 'slick' ), '1.0', true );
	}
	wp_enqueue_script( 'book-author-template-active', esc_url( get_template_directory_uri() ) . '/assets/js/active.js', array( 'jquery' ), '1.0', true );
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'book_author_template_scripts' );

add_action('customize_controls_enqueue_scripts', 'book_author_template_customizer_scripts');
function book_author_template_customizer_scripts(){
	wp_enqueue_style('customizer-style', esc_url(get_theme_file_uri('assets/customizer/customizer-style.css')));
	wp_enqueue_script('bat-kirki-custom-script', esc_url(get_theme_file_uri('assets/customizer/customizer-custom-script.js')), array('jquery'), '49879', true);
}

add_action('enqueue_block_editor_assets', 'book_author_template_global_scripts');
add_action('wp_enqueue_scripts', 'book_author_template_global_scripts');

function book_author_template_global_scripts(){
	wp_enqueue_style( 'bootstrap-grid', esc_url(get_theme_file_uri( 'assets/css/bootstrap-grid.css' )) );
	wp_enqueue_style( 'rswpthemes-icons', esc_url(get_theme_file_uri( 'assets/css/icons.css' )) );
	wp_enqueue_style( 'block-style', esc_url(get_theme_file_uri( 'assets/blocks-style/block-styles.css' )) );
	/**
	 * Title Border Color
	 */
	$getTitleBorderColor = get_theme_mod('primary_bg_color', '#228B22');
	$containerWidth = '1200';
	$containerWidth = get_theme_mod('container_custom_width', '1200');

    // Global Color Variables
    $global_heading_color = get_theme_mod('global_heading_color', '#000000');
    $global_body_color = get_theme_mod('global_body_color', '#000000');
    $global_bg_color_1 = get_theme_mod('global_bg_color_1', '#ffffff');
    $global_bg_color_2 = get_theme_mod('global_bg_color_2', '#f1f1f1');
    $global_bg_color_3 = get_theme_mod('global_bg_color_3', '#228B22');

    // Global Typography Variables
    $global_heading_font = get_theme_mod('global_heading_font', array('font-family' => 'Roboto', 'variant' => '700'));
    $global_body_font = get_theme_mod('global_body_font', array('font-family' => 'Roboto', 'variant' => 'regular'));

    $heading_font_family = isset($global_heading_font['font-family']) ? $global_heading_font['font-family'] : 'Roboto';
    $body_font_family = isset($global_body_font['font-family']) ? $global_body_font['font-family'] : 'Roboto';

	$inline_style_data = '
		:root {
			--global-heading-color: ' . esc_attr($global_heading_color) . ';
			--global-body-color: ' . esc_attr($global_body_color) . ';
			--global-bg-color-1: ' . esc_attr($global_bg_color_1) . ';
			--global-bg-color-2: ' . esc_attr($global_bg_color_2) . ';
			--global-bg-color-3: ' . esc_attr($global_bg_color_3) . ';
			--global-heading-font: ' . esc_attr($heading_font_family) . ', sans-serif;
			--global-body-font: ' . esc_attr($body_font_family) . ', sans-serif;
		}
		@media (min-width: 1300px) {
			.container{
				max-width: '.$containerWidth.'px;
			}
		}
		.book-author-template-standard-post__post-title h2 a, .book-author-template-standard-post__post-title h3 a, ul.recent-post-widget li .recent-widget-content h2 a{
            background-image: linear-gradient(to right, '.$getTitleBorderColor.' 0%, '.$getTitleBorderColor.' 100%);
        }
	';
	wp_add_inline_style('block-style', $inline_style_data);
}


