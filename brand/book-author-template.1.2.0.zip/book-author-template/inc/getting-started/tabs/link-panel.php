<?php
/**
 * Right Buttons Panel.
 *
 * @package Book Author Template
 */
?>
<div class="panel-right">
	<div class="panel-aside">
		<h4><?php esc_html_e( 'Upgrade Your Website to Pro', 'book-author-template' ); ?></h4>
		<p><?php esc_html_e( 'As an author, your challenges are different than other website owners. You know how vital every reader is and why it is crucial that they stay connected with you past that first visit. Book Author Template Pro is the premium theme created for authors and their needs. From our one-click settings import to our distinct features like author bio panels, book sliders, book pages, and more.', 'book-author-template' ); ?></p>
		<p><?php esc_html_e( 'If you like the way our free theme looks, you will fall in love with the design and functionality of Book Author Template Pro. Make sure you look at our demo by clicking the button below.', 'book-author-template' ); ?></p>
		<a class="button button-primary" href="<?php echo esc_url( book_author_template_utm_url('getting_started_page') ); ?>" title="<?php esc_attr_e( 'View Premium Version', 'book-author-template' ); ?>" target="_blank">
            <?php esc_html_e( 'Learn More About Book Author Template Pro >>', 'book-author-template' ); ?>
        </a>
	</div><!-- .panel-aside Theme Support -->
</div><!-- .panel-right -->