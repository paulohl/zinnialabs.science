<?php
/**
 * Help Panel.
 *
 * @package Book Author Template
 */
?>
<!-- Updates panel -->
<div id="plugins-panel" class="panel-left visible">
  <h4><?php _e( 'Author Portfolio Free WordPress Theme Setup, and Walkthrough Video.', 'book-author-template' ); ?></h4>
    <iframe width="900" height="500" src="https://www.youtube.com/embed/iy_l-Mbk7pk?si=gHISCtKxbyBxQcwq" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
	<p><?php _e( 'Thank you for using our Book Author Template WordPress theme. We hope you\'re enjoying it! We wanted to remind you that some of the features shown in our video instructions are only available in the pro version of the theme. If you\'re interested in accessing those additional features, you can upgrade to the pro version by clicking Upgrade To Pro Link. Thank you for your understanding, and please let us know if you have any questions or feedback.', 'book-author-template' );?></p>

	<hr>
	<br>
	<h4><?php _e( 'How To Add Navigation Menu To Your Website and Customize Header Layout.', 'book-author-template' ); ?></h4>
	<div>
     <iframe width="900" height="500" src="https://www.youtube.com/embed/pKe4WaqA-Nc" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
    </div>
	<hr/>
    <h4><?php _e( 'How to add book to your website.', 'book-author-template' ); ?></h4>
    <div>
     <iframe width="900" height="500" src="https://www.youtube.com/embed/efF130jkcS8" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
    </div>
    <hr/>
    <h4><?php _e( 'How To Display Book Slider On The Blog Page Below The Header.', 'book-author-template' ); ?></h4>
    <div>
      <iframe width="900" height="500" src="https://www.youtube.com/embed/XA08d3QQ39c" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
    </div>
    <hr/>
    <h4><?php _e( 'How To Display Books to your website sidebar.', 'book-author-template' ); ?></h4>
    <div>
      <iframe width="900" height="500" src="https://www.youtube.com/embed/zs6c26AGVVY" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
    </div>
    <hr/>

	<a class="button button-primary" style="width:100%; text-align:center;" href="<?php echo esc_url( book_author_template_utm_url('getting_started_page') ); ?>" title="<?php esc_attr_e( 'View Premium Version', 'book-author-template' ); ?>" target="_blank">  <?php esc_html_e( 'Learn More About Book Author Template Pro >>', 'book-author-template' ); ?>
    </a>
	<hr/>
</div><!-- .panel-left -->