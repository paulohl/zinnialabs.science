<?php
add_action( 'admin_footer', 'book_author_template_admin_footer_ads' );
function book_author_template_admin_footer_ads(){
	?>
	<div class="book_author_template-admin-footer-ad-wrapper" id="rswpbs-banner-ad">
		<div class="book_author_template-admin-footer-ad-inner">
			<div class="close-popup">
				<div class="rswpbs-banner-close"><span class="dashicons dashicons-no-alt"></span></div>
			</div>
			<div class="book_author_template-ad-image image-left">
				 <img src="<?php echo esc_url(get_theme_file_uri('inc/install-rswpbs/book-author-template-pro-thumb.png'));?>" alt="<?php esc_attr_e('RS WP BOOK SHOWCASE', 'book-author-template');?>">
			</div>
			<div class="book_author_template-ad-content">
			    <h2><?php esc_html_e('Take Your Book Display to the Next Level!', 'book-author-template'); ?></h2>
			    <p><?php esc_html_e('Do you feature books on your website? Make them stand out with the RS WP Book Showcase Plugin – a must-have plugin for authors, bloggers, and publishers.', 'book-author-template'); ?></p>
			    <ul>
			        <li>✅ <?php esc_html_e('Showcase your books in a stunning, organized layout.', 'book-author-template'); ?></li>
			        <li>✅ <?php esc_html_e('Customize it to fit your website\'s unique style.', 'book-author-template'); ?></li>
			        <li>✅ <?php esc_html_e('Boost engagement with a user-friendly, mobile-responsive design.', 'book-author-template'); ?></li>
			    </ul>
			    <p><?php esc_html_e('And the best part? It\'s FREE to install!', 'book-author-template'); ?></p>
			    <p><strong><?php esc_html_e('Unlock a beautiful book showcase with just one click.', 'book-author-template'); ?></strong><br>
			    <?php esc_html_e('Click', 'book-author-template'); ?> <strong><?php esc_html_e('Install Now', 'book-author-template'); ?></strong> <?php esc_html_e('and start transforming your book display today!', 'book-author-template'); ?></p>
			    <a class="rswpbs-install" href="#"><?php esc_html_e('Install Now', 'book-author-template'); ?></a>
			    <a class="rswpbs-learn-more" target="_blank" href="<?php echo esc_url('https://rswpthemes.com/rs-wp-book-showcase-wordpress-plugin/');?>"><?php esc_html_e('View Details', 'book-author-template'); ?></a>
			</div>
		</div>
	</div>
	<?php
}

/**************************
 *   RSWPBS Installer
 **************************/

 //Admin Enqueue for Admin
function book_author_template_install_rswpbs(){
	wp_enqueue_style( 'book_author_template-rswpbs-install', get_theme_file_uri( '/inc/install-rswpbs/install-rswpbs.css') );
	wp_enqueue_script( 'book_author_template-rswpbs-installer', get_theme_file_uri('/inc/install-rswpbs/install-rswpbs.js'), array( 'jquery' ), '', true );
    wp_localize_script( 'book_author_template-rswpbs-installer', 'book_author_template_rswpbs_ajax_object',
        array(
        	'ajax_url' => admin_url( 'admin-ajax.php' ),
        	'nonce'    => wp_create_nonce('rswpbs_install_nonce')
        ),
    );
}
add_action( 'admin_enqueue_scripts', 'book_author_template_install_rswpbs' );

add_action( 'wp_ajax_install_rswpbs_plugin', 'book_author_template_rswpbs_install_plugin' );

function book_author_template_rswpbs_install_plugin() {
    // 1. CSRF Nonce Check
    check_ajax_referer( 'rswpbs_install_nonce', 'nonce' );

    // 2. User Permission Check
    if ( ! current_user_can( 'install_plugins' ) || ! current_user_can( 'activate_plugins' ) ) {
        wp_send_json_error( array( 'message' => __( 'Insufficient permissions to perform this action.', 'book-author-template' ) ) );
    }

    include_once ABSPATH . 'wp-admin/includes/file.php';
    include_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
    include_once ABSPATH . 'wp-admin/includes/plugin-install.php';

    if ( ! file_exists( WP_PLUGIN_DIR . '/rs-wp-books-showcase' ) ) {
        $api = plugins_api( 'plugin_information', array(
            'slug'   => sanitize_key( 'rs-wp-books-showcase' ),
            'fields' => array(
                'sections' => false,
            ),
        ) );

        if ( is_wp_error( $api ) ) {
            wp_send_json_error( array( 'message' => $api->get_error_message() ) );
        }

        $skin     = new WP_Ajax_Upgrader_Skin();
        $upgrader = new Plugin_Upgrader( $skin );
        $result   = $upgrader->install( $api->download_link );

        if ( is_wp_error( $result ) ) {
            wp_send_json_error( array( 'message' => $result->get_error_message() ) );
        }
    }

    // Activate Plugin
    $plugin_file = 'rs-wp-books-showcase/rs-wp-books-showcase.php';
    if ( file_exists( WP_PLUGIN_DIR . '/' . $plugin_file ) && ! is_plugin_active( $plugin_file ) ) {
        $activated = activate_plugin( $plugin_file );
        if ( is_wp_error( $activated ) ) {
            wp_send_json_error( array( 'message' => $activated->get_error_message() ) );
        }
    }

    wp_send_json_success( array( 'message' => __( 'Plugin successfully installed and activated.', 'book-author-template' ) ) );
}