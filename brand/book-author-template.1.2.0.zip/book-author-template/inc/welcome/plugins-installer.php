<?php
/**************************
 * Plugin Installer
 **************************/

// Admin Enqueue for Admin
function book_author_template_admin_enqueue_scripts() {
    wp_enqueue_script( 'book-author-template-plugin-installer', get_theme_file_uri( '/inc/welcome/welcome-notice.js' ), array( 'jquery' ), '', true );
    wp_localize_script(
        'book-author-template-plugin-installer',
        'book_author_template_ajax_object',
        array( 'ajax_url' => admin_url( 'admin-ajax.php' ) )
    );
}
add_action( 'admin_enqueue_scripts', 'book_author_template_admin_enqueue_scripts' );

add_action( 'wp_ajax_install_act_plugin', 'book_author_template_admin_install_plugin' );

function book_author_template_admin_install_plugin() {

    include_once ABSPATH . 'wp-admin/includes/plugin.php';

    /**
     * 1️⃣ Plugins that can be INSTALLED + ACTIVATED
     */
    $installable_plugins = array(
        'rs-author-info-box'       => 'rs-author-info-box/rs-author-info-box.php',
        'rs-wp-books-showcase'     => 'rs-wp-books-showcase/rs-wp-books-showcase.php',
        'author-website-templates' => 'author-website-templates/author-website-templates.php',
        'advanced-import'          => 'advanced-import/advanced-import.php',
    );

    /**
     * 2️⃣ Pro plugins (ONLY activate if already installed)
     */
    $pro_plugins = array(
        'rs-wp-books-showcase-pro/rs-wp-books-showcase-pro.php',
        'author-website-templates-pro/author-website-templates-pro.php',
    );

    /**
     * ----------------------------------
     * Install + Activate normal plugins
     * ----------------------------------
     */
    include_once ABSPATH . 'wp-admin/includes/file.php';
    include_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
    include_once ABSPATH . 'wp-admin/includes/plugin-install.php';

    if ( ! WP_Filesystem() ) {
        wp_send_json_error( array( 'message' => 'Filesystem permission error.' ) );
    }

    $skin     = new WP_Upgrader_Skin();
    $upgrader = new Plugin_Upgrader( $skin );

    foreach ( $installable_plugins as $slug => $main_file ) {

        if ( ! file_exists( WP_PLUGIN_DIR . '/' . dirname( $main_file ) ) ) {

            $api = plugins_api( 'plugin_information', array(
                'slug'   => sanitize_key( $slug ),
                'fields' => array( 'sections' => false ),
            ) );

            if ( is_wp_error( $api ) ) {
                continue;
            }

            ob_start();
            $upgrader->install( $api->download_link );
            ob_end_clean();
        }

        if ( file_exists( WP_PLUGIN_DIR . '/' . $main_file ) && ! is_plugin_active( $main_file ) ) {
            activate_plugin( $main_file );
        }
    }

    /**
     * ----------------------------------
     * Activate ONLY installed PRO plugins
     * ----------------------------------
     */
    foreach ( $pro_plugins as $pro_plugin ) {

        if ( file_exists( WP_PLUGIN_DIR . '/' . $pro_plugin ) ) {

            if ( ! is_plugin_active( $pro_plugin ) ) {
                activate_plugin( $pro_plugin );
            }
        }
    }

    wp_send_json_success( array(
        'message' => 'Installed plugins activated. Pro plugins activated only if already installed.'
    ) );
}
