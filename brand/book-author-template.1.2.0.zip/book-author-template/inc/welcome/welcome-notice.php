<?php
/**
 * Getting Started Help Notic
 **/
function book_author_template_general_admin_notice(){
    $screen = get_current_screen();
    if ( $screen->id === 'appearance_page_advanced-import' || $screen->id === 'appearance_page_book-author-template-getting-started' ) {
        return;
    }
?>
<div data-dismissible="disable-done-notice-forever" class="notice notice-info book-author-template-welcome-notice">
    <div class="book-author-template-notice-wrapper">
        <div class="book-author-template-notice-inner">
            <div class="notice-thumbnail-col">
              <img src="<?php echo esc_url(get_theme_file_uri('assets/img/author-portfolio-pro-thumb.png'));?>" alt="<?php esc_attr_e('Author Portfolio Pro', 'book-author-template');?>">
            </div>
            <div class="notice-content-col">
              <h3>
               <?php esc_html_e('Thank you for installing the Book Author Template WordPress Theme.', 'book-author-template'); ?>
              </h3>
              <p class="notice-desc">
              <?php esc_html_e('Ready to create a stunning author website? Click the Install Starter Author Website Templates button, and you\'ll be redirected to our demo page to get started.', 'book-author-template'); ?>
              </p>
              <p>
              <a class="book-author-template-btn-get-started button button-primary book-author-template-button-padding" href="#" data-name="" data-slug="">
                <?php esc_html_e( 'Install Starter Author Website Templates', 'book-author-template' );?>
              </a>
              <a href="<?php echo esc_url(admin_url( 'themes.php?page=book-author-template-getting-started' ));?>" class="button button-highlight btn-doc button-primary" style="color:#fff;">
                <span style="margin-top:4px;margin-right:5px;" class="dashicons dashicons-video-alt3"></span>
                <?php esc_html_e( ' Getting started videos', 'book-author-template' );?>
            </a>
            <a target="_blank" href="<?php echo esc_url(book_author_template_utm_url('welcome_notice'));?>" class="button button-highlight upgrade-to-pro button-primary">
                <?php esc_html_e( 'Upgrade To Pro', 'book-author-template' );?>
            </a>
            <a href="?book_author_template_notice_dismissed" style="text-decoration: none; float: right;">
              <?php esc_html_e( 'Dismiss Notice', 'book-author-template' );?>
            </a>
            </p>
            </div>
        </div>
    </div>
</div>
<?php
}

if ( isset( $_GET['book_author_template_notice_dismissed'] ) ){
   update_option('book_author_template_help_notice', 'notice_book_author_template_dismissed');
   set_transient('book_author_template_welcome_notice_dismissed_time', time(), 2 * 60 * 60);
}

add_action('admin_init', function(){
    $book_author_template_help_notice = get_option('book_author_template_help_notice', '');
    if('notice_book_author_template_dismissed' === $book_author_template_help_notice) {
        $dismissed_time = get_transient('book_author_template_welcome_notice_dismissed_time');
        if (false === $dismissed_time || time() > $dismissed_time + ( 2 * 60 * 60 )) {
            delete_option('book_author_template_notice_dismissed');
            delete_transient('book_author_template_welcome_notice_dismissed_time');
            add_action('admin_notices', 'book_author_template_general_admin_notice');
        }
    }
});

$book_author_template_help_notice = get_option('book_author_template_help_notice', '');
if (($book_author_template_help_notice != 'notice_book_author_template_dismissed' || $book_author_template_help_notice === '') ){
   add_action('admin_notices', 'book_author_template_general_admin_notice');
}
