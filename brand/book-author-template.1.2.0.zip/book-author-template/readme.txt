=== Book Author Template ===
Contributors: rswpthemes
Tags: blog, news, e-commerce, grid-layout, one-column, two-columns, three-Columns, four-Columns, left-sidebar, right-sidebar, custom-background, custom-colors, custom-header, custom-logo, custom-menu, editor-style, footer-widgets, flexible-header, theme-options, translation-ready, featured-images, block-styles, wide-blocks, sticky-post, featured-image-header, front-page-post-form, full-width-template, post-formats, threaded-comments
Requires at least: 5.0
Tested up to: 7.0
Requires PHP: 7.4
Stable tag: 1.2.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
Book Author Template is a beautiful and easy-to-use WordPress theme for authors, writers, novelists, and publishers who want to launch, promote or publish their books online. It is carefully designed to follow the trends of today’s modern web while providing full support for the new WordPress 5 block editor (Gutenberg ready). This theme features an elegant and attractive layout to help you generate high leads and get more sales of your book. With the Book Author Template theme, you can create a fully responsive, and visually appealing landing page to sell and promote your book without writing a single line of code. It is a speed-optimized theme that helps your website load within a blink of an eye and provides a great user experience to your visitors. The theme is developed with SEO-optimized codes and is schema.org markup ready to help your website rank higher in Google and other search engines. Furthermore, this theme is fully compatible with the popular WooCommerce plugin to allow you to sell your book via your website.

== Frequently Asked Questions ==

= How to Install Theme =
1. In your admin panel, go to Appearance > Themes and click the Add New button and Search for Book Author Template, OR
2. If you have theme zip file, click Upload and choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.


== Changelog ==

= 1.2.0 - Jul 23, 2026 =
* Fixed CSRF vulnerability in plugin installation AJAX handler
* Added nonce and capability checks for secure plugin activation

= 1.1.9 - Jun 20, 2026 =
* Security Fix: Added nonce and user capability in metabox.

= 1.1.8 - May 17, 2026 =
* Fix warning issue in archive.php, search.php, index.php

= 1.1.7 - Jan 22, 2026 =
* Solved Minor Error

= 1.1.6 - Jan 22, 2026 =
* Fully Compatible with Author Website Templates Plugin
* Improved Demo installer experience

= 1.1.5 - Nov 20, 2025 =
* Improved Color Customizer

= 1.1.4 - Sep 03, 2025 =
* Improved Header Responsive Design

= 1.1.3 - April 23, 2025 =
* Solved Translation Warnings of wp 6.7 version

= 1.1.2 - March 13, 2025 =
* Added Demo Setup Process

= 1.1.1 - Feb 15, 2025 =
* Solved Post Page sidebar layout issue.

= 1.1.0 - Feb 1, 2025 =
* Solved Kirki Repeater issue

= 1.0.9 - Dec 11, 2024 =
* Added Meta Box To hide featured image from single page.

= 1.0.8 - Nov 04, 2024 =
* Removed RSWPBS Installer
* Added Latest RSWPBS Icons
* Improved Design Of Archive List Block, Category List Block, Latest Comments Block

= 1.0.7 - Sep 27, 2024 =
* Added RS WP BOOK SHOWCASE BANNER

= 1.0.6 - Sep 19, 2024 =
* Improved block pagination and navigation link design

= 1.0.5 - Aug 31, 2024 =
* Added Page Meta Options

= 1.0.4 - Aug 11, 2024 =
* Social link target set to blank

= 1.0.3 - Aug 05, 2024 =
* Work Perfectly with Latest WordPress

= 1.0.2 - July 02, 2024 =
* Added Pro Links and Plugin Installer

= 1.0.1 - Jun 29, 2024 =
* Initial release

= 1.0.0 - Jun 10, 2024 =
* Initial release

== Copyright ==
Book Author Template WordPress Theme, Copyright 2025 rswpthemes.com
Book Author Template is distributed under the terms of the GNU GPL
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

Book Author Template bundles the following third-party resources:
* Unless otherwise specified, all the theme files, scripts and images are licensed under GNU General Public License Version 2 or later.
* Based on Underscores http://underscores.me/, (C) 2012-2015 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
* normalize.css http://necolas.github.io/normalize.css/, (C) 2012-2015 Nicolas Gallagher and Jonathan Neal, [MIT](http://opensource.org/licenses/MIT)
* CSS bootstrap-grid.css
  Copyright 2011-2020 The Bootstrap Authors
  Copyright 2011-2020 Twitter, Inc.
  Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)
* Font Awesome 4.7.0 by @davegandy - http://fontawesome.io - @fontawesome
  License - http://fontawesome.io/license (Font: SIL OFL 1.1, CSS: MIT License)
* Slick 1.8.0 by Ken Wheeler - http://kenwheeler.github.io
  License - https://github.com/kenwheeler/slick/blob/master/LICENSE

== License/copyright for images ==
* logo.png and book cover self created.
* Screenshot images are all licensed under CC0 Universal

Image for theme screenshot
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/en/photo/1198957

Image for theme screenshot
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/en/photo/625568
