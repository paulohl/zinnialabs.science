<?php
/**
 * The template for displaying search results pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#search-result
 *
 * @package Book Author Template
 */
get_header();

// Theme Implementation for Archives/Special Pages
$awt_settings      = get_option( 'awt_global_settings', array() );
$title_template_id = isset( $awt_settings['awt_page_title_template_id'] ) ? $awt_settings['awt_page_title_template_id'] : '';
$title_template_id = function_exists( 'rswpthemes_awt_get_block_id_by_slug' ) ? rswpthemes_awt_get_block_id_by_slug( $title_template_id ) : false;

if ($title_template_id && $post_block = get_post($title_template_id)) {
	echo do_blocks($post_block->post_content);
} else {
	if (true === book_author_template_page_header_control()) {
		get_template_part('template-parts/page-header/page', 'header');
	}
}
$awt_settings = get_option('awt_global_settings', []);
$blog_slug = $awt_settings['awt_blog_template_id'] ?? '';
$blog_template_id = function_exists('rswpthemes_awt_get_block_id_by_slug') ? rswpthemes_awt_get_block_id_by_slug($blog_slug) : false;

if (class_exists('Rswpthemes_Author_Website_Templates') && $blog_template_id && $post = get_post($blog_template_id)):
	echo do_blocks($post->post_content);
else:
	?>
		<section id="primary" class="content-area archive-page-section">
			<main id="main" class="site-main">
				<?php
				do_action( 'book_author_template_before_default_page' );
				if ( have_posts() ) :
					echo '<div class="row'.book_author_template_masonry_layout_control().'">';
						/* Start the Loop */
						while ( have_posts() ) :
							the_post();
							get_template_part( 'template-parts/content/content', 'search' );
						endwhile;
						echo '</div>';
						book_author_template_navigation();
					else :
						get_template_part( 'template-parts/content/content', 'none' );
					endif;
					do_action( 'book_author_template_after_default_page' );
					?>
			</main><!-- #main -->
		</section><!-- #primary -->
	<?php
endif;
get_footer(); ?>
