<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package Book Author Template
 */
get_header();
?>
<div id="primary" class="content-area">
	<main id="main" class="site-main">
		<?php do_action('book_author_template_before_default_page'); ?>
			<div class="post-details-page">
				<?php
				while ( have_posts() ) :
					the_post();
					get_template_part( 'template-parts/content/content', 'event');
				endwhile; // End of the loop.
				book_author_template_post_page_navigation();
				?>
			</div>
		<?php do_action('book_author_template_after_default_page'); ?>
	</main><!-- #main -->
</div><!-- #primary -->
<?php
get_footer();
