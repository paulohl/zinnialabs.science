<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package Book Author Template
 */
get_header();
$awt_settings = get_option('awt_global_settings', []);
$single_slug = $awt_settings['awt_blog_single_template_id'] ?? '';
$blog_template_id = function_exists('rswpthemes_awt_get_block_id_by_slug') ? rswpthemes_awt_get_block_id_by_slug($single_slug) : false;

while (have_posts()):
	the_post();
	if (class_exists('Rswpthemes_Author_Website_Templates') && $blog_template_id && $template_post = get_post($blog_template_id)):
		echo do_blocks($template_post->post_content);
	else:
	$s_post_el_is_on = array(
		'show_recommend_posts' => get_theme_mod('show_recommend_posts', true),
		'show_post_navigation' => get_theme_mod('show_post_navigation', true),
		'show_post_author_box' => get_theme_mod('show_post_author_box', true),
		'post_layout' => get_theme_mod('post_page_layout', '1'),
	);
	?>
	<div id="primary" class="content-area">
		<main id="main" class="site-main">
			<?php do_action('book_author_template_before_default_page'); ?>
				<div class="post-details-page">
					<?php
					get_template_part( 'template-parts/content/content', 'single' );
					if(true == $s_post_el_is_on['show_post_navigation']):
						book_author_template_post_page_navigation();
					endif;

					if( true == $s_post_el_is_on['show_post_author_box'] ) :
						book_author_template_postedby();
					endif;
					// If comments are open or we have at least one comment, load up the comment template.
					if ( comments_open() || get_comments_number() ) :
						comments_template();
					endif;
					if (true == $s_post_el_is_on['show_recommend_posts']) :
						echo '<div class="related-post-wrapper">';
							book_author_template_cats_related_post();
						echo '</div>';
					endif;
					?>
				</div>
			<?php do_action('book_author_template_after_default_page'); ?>
		</main><!-- #main -->
	</div><!-- #primary -->
	<?php
	endif;
endwhile;
get_footer();
