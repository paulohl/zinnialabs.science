<?php
$row_class = '';
if(is_post_type_archive('event')){
	$row_class = $args['row_class'];
}
$contentAlignmentClass = '';

$event_date = get_post_meta(get_the_ID(), 'event_date', true);

if( is_front_page() || is_post_type_archive( 'event' ) ){
	$contentAlignmentClass = ' align-self-center';
}
?>
<div class="book-author-template-book-events-section">
	<div class="container book-events-wrapper">
		<div class="row book-events-item book-events-row <?php echo esc_attr( $row_class ); ?>">
		    <div class="col-lg-5 col-md-6 book-events-column book-events-cover-column <?php echo esc_attr( $contentAlignmentClass ); ?>">
				<div class="book-events-cover-wrapper">
					<a href="<?php echo esc_url( get_the_permalink() );?>"><?php echo get_the_post_thumbnail(); ?></a>
				</div>
			</div>
			<div class="col-lg-7 col-md-6 pr-xl-5 book-events-column book-evebts-content-column <?php echo esc_attr( $contentAlignmentClass ); ?>">
				<div class="book-events-content-wrapper">
					<div class="book-events-content-container">
						<h2 class="book-title"><a href="<?php echo esc_url( get_the_permalink() );?>"><?php  the_title(); ?></a></h2>
						<div class="book-events-desc"><?php the_content(); ?></div>
						<?php if (!empty($event_date)) : ?>
						<div><p><span class="dashicons dashicons-clock"></span><?php echo esc_html($event_date); ?></p></div>
						<?php endif; ?>
						<?php if(is_front_page() || is_post_type_archive( 'event')):?>
						<div class="book-buttons">
							<div class="book-buy-btn"><a href="<?php echo esc_url( get_the_permalink() );?>"><?php esc_html_e( 'See Details', 'book-author-template' );?></a></div>
						</div>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
