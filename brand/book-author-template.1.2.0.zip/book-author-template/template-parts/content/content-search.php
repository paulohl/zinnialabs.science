<?php
/**
 * Template part for displaying results in search pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Book Author Template
 */
get_template_part( 'template-parts/content/post', 'layout' );