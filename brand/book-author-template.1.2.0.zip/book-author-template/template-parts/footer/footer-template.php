<?php
$show_scroll_to_top_button = get_theme_mod('show_scroll_to_top_button', true);
$button_extra_class = '';
if (true == get_theme_mod('hide_button_on_mobile_device', true)) {
	$button_extra_class = ' hide-button-on-mobile';
}
$showFooterTop = true;
$showFooterTop = get_theme_mod('show_footer_top_section', true);
?>
</div><!-- #content -->
<footer id="colophon" class="site-footer">
	<?php
	if (true == $showFooterTop) {
		get_template_part('template-parts/footer/footer-top-area');
	}
	?>
	<!-- Footer Copyright Section -->
	<section class="site-copyright">
		<div class="container">
			<div class="row">
				<div class="col-md-12 align-self-center">
					<div class="site-info text-center">
						<div class="site-copyright-text d-inline-block">
						<?php
						echo wp_kses_post( 'Copyright <i class="rswpthemes-icon icon-copyright-solid" aria-hidden="true"></i> 2024. All rights reserved.', 'book-author-template' );
						?>
						</div>
					</div><!-- .site-info -->
					<?php
						book_author_template_credit();
					?>
				</div>
			</div>
		</div>
	</section>
</footer><!-- #colophon -->
<?php if(true == $show_scroll_to_top_button) : ?>
<div class="scrooltotop<?php echo esc_attr($button_extra_class);?>">
	<a href="#" class="rswpthemes-icon icon-angle-up-solid"></a>
</div>
<?php endif; ?>