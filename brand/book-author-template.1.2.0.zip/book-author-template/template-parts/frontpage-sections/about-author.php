<?php
/**
 * Section About Me
 */
$show_social_links = get_theme_mod('show_about_section_social_links', true);
$followMeText = get_theme_mod('about_follow_me_text', __('Follow Me', 'book-author-template'));
$welcomeText = get_theme_mod('about_welcome_text', __('Meet Author', 'book-author-template'));
$buttonText = get_theme_mod('about_button_text', __('About Me', 'book-author-template'));
$buttonLink = get_theme_mod('about_button_link', '#');
$getAboutMePageSlug = get_theme_mod('about_me_page');
if (empty($getAboutMePageSlug)) {
	return;
}
$getAboutMePage = get_page_by_path($getAboutMePageSlug);
$shortDescription = $getAboutMePage->post_excerpt;
$shortDescription = '<p>' . str_replace("\n", '</p><p>', $shortDescription) . '</p>';
?>
<div class="book-author-template-about-me-section">
	<div class="container about-me-section-container">
		<div class="row about-me-section-row">
			<div class="col-md-6 align-self-center about-me-image-column">
				<div class="about-me-image-container">
					<?php echo wp_kses_post(get_the_post_thumbnail($getAboutMePage->ID, 'full')); ?>
				</div>
			</div>
			<div class="col-md-6 align-self-center about-me-content-column">
				<div class="about-me-content-wrapper">
					<h5 class="welcome-text"><?php echo esc_html( $welcomeText );?></h5>
					<h2 class="author-name"><?php echo wp_kses_post($getAboutMePage->post_title); ?></h2>
					<div class="author-descriptions">
						<?php echo wp_kses_post($shortDescription); ?>
					</div>
					<div class="button-and-link-wrapper">
						<div class="about-me-button">
							<a href="<?php echo esc_url($buttonLink);?>"><?php echo esc_html($buttonText);?></a>
						</div>
						<?php
						if (true == $show_social_links) :
						?>
						<div class="follow-me-icons">
							<div class="text"><span><?php echo esc_html( $followMeText );?>:</span></div>
							<div class="social-icons"><?php book_author_template_social_links();?></div>
						</div>
						<?php
						endif;
						?>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>