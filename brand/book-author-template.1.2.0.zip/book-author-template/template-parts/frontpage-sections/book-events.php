<?php
/**
 * Book Events
 */
$queryArgs = array(
	'post_type' => 'event',
	'posts_per_page' =>1,
);
$eventQuery = new WP_Query( $queryArgs );
if ($eventQuery->have_posts()) :
	while($eventQuery->have_posts()):
		$eventQuery->the_post();
		get_template_part( 'template-parts/content/content', 'event');
	endwhile;
endif;
wp_reset_postdata();
