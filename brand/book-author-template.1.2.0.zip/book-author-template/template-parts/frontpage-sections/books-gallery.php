<?php
if (!class_exists('Rswpbs')) {
	return;
}

$showSectionTitle = true;
if (class_exists('Book_Author_Template_Pro')) {
	$showSectionTitle = get_theme_mod('books_gallery_show_section_title', true);
}

$allBooksSubHeading = get_theme_mod('book_author_template_all_books_sec_sub_heading', __('Author’s All Book', 'book-author-template'));
$allBooksHeading = get_theme_mod('book_author_template_all_books_sec_heading', __('Discover the Best of Taylor Jenking Reid', 'book-author-template'));
$allBooksDesc = get_theme_mod('book_author_templateall_books_sec_desc', __('has written an extensive collection of books spanning multiple genres. Their captivating storytelling and richly imagined worlds feature complex characters and engrossing plots that keep', 'book-author-template'));
$showSectionTitleCol = true;
if (empty($allBooksSubHeading) && empty($allBooksHeading)) :
	$showSectionTitleCol = false;
endif;

?>
<div class="book-author-template-all-books-area">
	<?php
	if (true == $showSectionTitle) :
	?>
	<div class="container section-title-container">
		<div class="row">
			<?php
			if (true == $showSectionTitleCol) :
			?>
			<div class="col-md-6">
				<div class="section-title-wrapper">
					<?php
					if (!empty($allBooksSubHeading)) :
					?>
					<h4 class="section-title-label"><?php echo esc_html($allBooksSubHeading);?></h4>
					<?php
					endif;
					if (!empty($allBooksHeading)) :
					?>
					<h2 class="section-title"><?php echo esc_html($allBooksHeading);?></h2>
					<?php
					endif;
					?>
				</div>
			</div>
			<?php
			endif;
			?>
			<div class="<?php echo (false == $showSectionTitleCol ? 'col-md-12' : 'col-md-6'); ?>">
				<div class="section-description-wrapper">
					<p><?php echo esc_html($allBooksDesc);?></p>
				</div>
			</div>
		</div>
	</div>
	<?php
	endif;
	?>
	<div class="book-author-templatebook-grid container">
	<?php
	$showBookImage = 'true';
	$bookImageType = 'book_cover';
	$showBookTitle = 'true';
	$bookTitleType = 'title';
	$showBookAuthor = 'true';
	$showBookPrice = 'true';
	$showBookExcerpt = 'true';
	$excerptLimit = 30;
	$showBuyButton = 'true';
	$booksPerRow = 4;
	$booksPerPage = 6;
	$includeCat = 'false';
	$excludeCat = 'false';
	$includeAuthors = 'false';
	$excludeAuthors = 'false';
	$excludeBooks = 'false';
	$bookOffset = 'false';
	$orderBy = 'default';
	$order = 'DESC';
	if (class_exists('Book_Author_Template_Pro')) :
		$showBookImage = (get_theme_mod('books_gallery_show_book_image', true) == '1' ? 'true' : 'false');
		$bookImageType = get_theme_mod('books_gallery_book_image_type', 'book_cover');
		$showBookTitle = (get_theme_mod('books_gallery_show_book_title', true) == '1' ? 'true' : 'false');
		$bookTitleType = get_theme_mod('books_gallery_book_title_type', 'title');
		$showBookAuthor = (get_theme_mod('books_gallery_book_author', true) == '1' ? 'true' : 'false');
		$showBookPrice = (get_theme_mod('books_gallery_book_price', true) == '1' ? 'true' : 'false');
		$showBookExcerpt = (get_theme_mod('books_gallery_book_excerpt', true) == '1' ? 'true' : 'false');
		$excerptLimit = get_theme_mod('books_gallery_book_excerpt_limit', 30);
		$showBuyButton = (get_theme_mod('books_gallery_book_buy_button', true) == '1' ? 'true' : 'false');
		$booksPerRow = get_theme_mod('books_gallery_books_per_row',4);
		$booksPerPage = get_theme_mod('books_gallery_books_per_page', 6);
		$includeCat = get_theme_mod('books_gallery_include_categories');
		$excludeCat = get_theme_mod('books_gallery_exclude_categories');
		$includeAuthors = get_theme_mod('books_gallery_include_authors');
		$excludeAuthors = get_theme_mod('books_gallery_exclude_authors');
		$excludeBooks = get_theme_mod('books_gallery_exclude_books');
		$bookOffset = get_theme_mod('books_gallery_books_offset');
		$orderBy = get_theme_mod('books_gallery_order_by', 'default');
		$order = get_theme_mod('books_gallery_order', 'DESC');
	endif;

	echo do_shortcode( "[rswpbs_book_gallery books_per_page=\"$booksPerPage\" books_per_row=\"$booksPerRow\" categories_include=\"$includeCat\" categories_exclude=\"$excludeCat\" authors_include=\"$includeAuthors\" authors_exclude=\"$excludeAuthors\" exclude_books=\"$excludeBooks\" order=\"$order\" orderby=\"$orderBy\" show_pagination=\"false\" show_author=\"$showBookAuthor\" show_title=\"$showBookTitle\" title_type=\"$bookTitleType\" show_image=\"$showBookImage\" image_type=\"$bookImageType\" image_position=\"top\" show_excerpt=\"$showBookExcerpt\" excerpt_type=\"excerpt\" excerpt_limit=\"$excerptLimit\" show_price=\"$showBookPrice\" show_buy_button=\"$showBuyButton\" show_msl=\"false\" msl_title_align=\"center\" content_align=\"center\" show_search_form=\"false\" show_sorting_form=\"false\" book_offset=\"$bookOffset\"]" );
		?>
	</div>
</div>

