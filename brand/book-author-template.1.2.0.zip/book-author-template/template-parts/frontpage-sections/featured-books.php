<?php
if (!class_exists('Rswpbs')) {
	return;
}

$showBookLabel = true;
$showBookLabelBorder = true;
$showBookTitle = true;
$showBookDescription = true;
$showBookAuthor = true;
$showButtonOne = true;
$showButtonTwo = true;
$showSliderNav = true;
$showOverlay = false;
if (class_exists('Book_Author_Template_Pro')) {
	$showBookLabel = get_theme_mod('show_featured_book_label', true);
	$showBookLabelBorder = get_theme_mod('show_featured_book_label_border', true);
	$showBookTitle = get_theme_mod('show_featured_book_title', true);
	$showBookDescription = get_theme_mod('show_featured_book_description', true);
	$showBookAuthor = get_theme_mod('show_featured_book_author', true);
	$showButtonOne = get_theme_mod('show_featured_book_btn_1', true);
	$showButtonTwo = get_theme_mod('show_featured_book_btn_2', true);
	$showSliderNav = get_theme_mod('show_featured_book_nav', true);
	$showOverlay = get_theme_mod('show_featured_book_bg_overlay', false);
}
$labelBorderClass = 'showLabelBorder';
if (false == $showBookLabelBorder || '0' == $showBookLabelBorder) {
	$labelBorderClass = 'hideLabelBorder';
}
$sliderNavClass = 'true';
if (false == $showSliderNav || '0' == $showSliderNav) {
	$sliderNavClass = 'false';
}
$getFeaturedBooks = get_theme_mod('featured_books');

if (is_array($getFeaturedBooks) && !empty($getFeaturedBooks)) :
	$itemCount = count($getFeaturedBooks);
?>
<div class="book-author-template-featured-books-section">
	<?php
	if (true == $showOverlay) {
		echo '<div class="overlay_color"></div>';
	}
	?>
	<div class="container featured-books-wrapper">
		<?php
		if ( $itemCount > 1) {
			echo "<div class='featured-book-slider-activate' data-nav='$sliderNavClass'>";
		}
		foreach($getFeaturedBooks as $getFeaturedbook) :
			$bookSlug = $getFeaturedbook['book_slug'];
			if (!empty($bookSlug)) :
			$getBook = get_page_by_path( $bookSlug, OBJECT, 'book' );
			$bookId = $getBook->ID;
			if ( $itemCount > 1) {
				echo "<div class='slider-item'>";
			}
			?>
			<div class="row align-items-center featured-book-item featured-book-row">
				<div class="col-lg-8 col-md-6 pr-xl-5 align-self-center featured-book-column featured-book-content-column">
					<div class="featured-book-content-wrapper">
						<div class="featured-book-content-container">
							<?php
							if ( true == $showBookLabel && !empty($getFeaturedbook['book_label'])) :
							?>
							<div class="book-label-wrapper <?php echo esc_attr( $labelBorderClass );?>">
								<h4 class="book-label"><?php echo $getFeaturedbook['book_label'];?></h4>
							</div>
							<?php
							endif;
							if (true == $showBookTitle) :
							?>
							<h2 class="book-title">
								<a href="<?php echo esc_url( get_the_permalink($bookId) );?>"><?php echo wp_kses_post( rswpbs_get_book_name( $bookId ) );?></a>
							</h2>
							<?php
							endif;
							if (true == $showBookAuthor) :
							?>
							<h4 class="book-author">(<?php echo wp_kses_post( rswpbs_get_book_author($bookId) );?>)</h4>
							<?php
							endif;
							if (true == $showBookDescription) :
							?>
							<div class="book-desc"><?php echo rswpbs_get_book_desc($bookId, 30); ?></div>
							<?php
							endif;
							if (true == $showButtonOne || true == $showButtonTwo) :
							?>
							<div class="book-buttons">
								<?php
								if (true == $showButtonOne) :
								?>
								<div class="book-buy-btn"><?php echo wp_kses_post( rswpbs_get_book_buy_btn($bookId) );?></div>
								<?php
								endif;
								if (true == $showButtonTwo) :
								?>
								<div class="book-details-btn"><a href="<?php echo esc_url( get_the_permalink($bookId) );?>"><?php esc_html_e( 'See Details', 'book-author-template' );?></a></div>
								<?php
								endif;
								?>
							</div>
							<?php
							endif;
							?>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6 align-self-center featured-book-column featured-book-cover-column">
					<div class="featured-book-cover-wrapper">
						<a href="<?php echo esc_url( get_the_permalink($bookId) );?>"><?php echo get_the_post_thumbnail( $bookId ); ?></a>
					</div>
				</div>
			</div>
			<?php
			if ( $itemCount > 1) {
				echo "</div>";
			}
			endif;
		endforeach;
		if ( $itemCount > 1) {
			echo "</div>";
		}
		?>
	</div>
</div>
<?php
endif;
?>