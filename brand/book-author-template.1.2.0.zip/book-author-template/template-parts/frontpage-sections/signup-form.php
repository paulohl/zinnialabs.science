<?php
/**
 * Email Signup Form Template
 */
$signupHeading = get_theme_mod('book_author_template_email_signup_heading', __('Want To Hear More From Taylor?', 'book-author-template'));
$signupSubHeading = get_theme_mod('book_author_template_email_signup_sub_heading', __('Sign up to receive news,updates, and exclusive content.', 'book-author-template'));
$fromShortcode = get_theme_mod('book_author_template_email_signup_shortcode');
?>
<div class="book-author-template-email-signup-section">
	<div class="container email-signup-wrapper">
		<div class="row align-items-center email-signup-item email-signup-row">
			<div class="col-lg-7 col-md-7 align-self-center email-signup-column email-signup-cover-column">
				<div class="email-signup-content-wrapper">
					<?php
					if (!empty($signupHeading)) :
					?>
					<h4 class="email-signup-title"><?php echo esc_html($signupHeading);?></h4>
					<?php
					endif;
					if (!empty($signupSubHeading)) :
					?>
					<p class="email-signup-desc"><?php echo esc_html($signupSubHeading);?></p>
					<?php
					endif;
					?>
				</div>
			</div>
			<?php
			if (!empty($fromShortcode)) :
			?>
			<div class="col-lg-5 col-md-5 align-self-center email-signup-column email-signup-content-column">
				<div class="email-signup-form-wrapper">
					<div class="email-signup-form-container">
						<?php echo wp_kses_post(do_shortcode( $fromShortcode )); ?>
					</div>
				</div>
			</div>
			<?php
			endif;
			?>
		</div>
	</div>
</div>