<?php
/**
 * Testominials Section
 */
$sectionHeading = get_theme_mod('book_author_template_testimonial_section_heading', __('Words From Our Happy Readers.', 'book-author-template' ));
$sectionSubHeading = get_theme_mod('book_author_template_testimonial_section_sub_heading', __( 'Testimonial', 'book-author-template' ));
$testimonialShortcodeAtts = array(
	'review_per_page'		=> '8',
	'review_layout' 		=> 'slider',
	'section_sub_heading' 		=> $sectionSubHeading,
	'section_heading' 		=> $sectionHeading,
	'select_book'			=>	'',
	'show_slider_nagivation'	=>	'true',
	'show_section_title'	=>	'true',
	'show_quote'	=>	'true',
	'show_ratings'	=>	'true',
	'show_reviewer'	=>	'true',
	'large_screen' => '3',
	'medium_screen' => '2',
	'small_screen' => '1',
	'layout_style' => 'classic',
);
$shortcode_atts = '';
foreach ($testimonialShortcodeAtts as $key => $value) {
    $shortcode_atts .= $key . '="' . $value . '" ';
}
// Remove trailing space
$shortcode_atts = rtrim($shortcode_atts);
?>
<div class="book-author-template-testimonial-section container">
	<?php
	echo do_shortcode('[rswpbs_reviews  '. $shortcode_atts .' ]');
	?>
</div>