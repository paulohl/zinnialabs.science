<?php
/**
* Template Name: Header Two
*
*/
$showSocialIcons = true;
$containerClass = 'container';
$showSocialIcons = get_theme_mod('show_social_icon', true);
$getHeaderContainer = get_theme_mod('header_container_size', 'container');
$containerClass = $getHeaderContainer;
if ('container-custom-size' == $getHeaderContainer) {
	$containerClass = 'container container-custom-size';
}
?>
<header id="masthead" class="site-header header-one" style="background-image: url(<?php echo esc_url( get_header_image() ); ?>);">
	<div class="header_overlay_color"></div>
	<div class="<?php echo esc_attr($containerClass);?>">
		<div class="row justify-content-between">
			<div class="col-md-12 col-lg-5 col-xl-3 align-self-center order-1 order-md-1 order-lg-1">
				<div class="site-branding header-logo text-md-center text-lg-left">
					<?php
					if ( has_custom_logo() ) :
						the_custom_logo();
					endif;
					?>
					<h1 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
						<?php
						$book_author_template_description = get_bloginfo( 'description', 'display' );
						if ( $book_author_template_description || is_customize_preview() ) :
							?>
						<p class="site-description"><?php echo esc_html( $book_author_template_description ); /* WPCS: xss ok. */ ?></p>
							<?php
					endif;
					?>
				</div><!-- .site-branding -->
			</div>
			<div class="mt-md-3 mt-0 mt-lg-0 mb-lg-0 col-md-12 col-lg-12 col-xl-9 m-auto align-self-center order-3 order-md-3 order-lg-3 order-xl-2 d-flex justify-content-between justify-content-md-center justify-content-lg-end text-right">
				<div class="cssmenu text-right align-self-center text-md-center" id="cssmenu">
					<?php
					if (has_nav_menu('main-menu')) :
						wp_nav_menu(
							array(
								'theme_location'    => 'main-menu',
								'container'         => 'ul',
								'fallback_cb'    => '__return_false',
							)
						);
					endif;
					?>
				</div>
			</div>
		</div>
	</div>
</header><!-- #masthead -->

