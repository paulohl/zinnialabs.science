/** @type {Construct} */
export const autolink: Construct;
import type { Construct } from 'micromark-util-types';
//# sourceMappingURL=autolink.d.ts.map