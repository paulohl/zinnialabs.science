/** @type {Construct} */
export const blankLine: Construct;
import type { Construct } from 'micromark-util-types';
//# sourceMappingURL=blank-line.d.ts.map