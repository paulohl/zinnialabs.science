/** @type {Construct} */
export const blockQuote: Construct;
import type { Construct } from 'micromark-util-types';
//# sourceMappingURL=block-quote.d.ts.map