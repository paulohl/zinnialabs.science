/** @type {Construct} */
export const characterEscape: Construct;
import type { Construct } from 'micromark-util-types';
//# sourceMappingURL=character-escape.d.ts.map