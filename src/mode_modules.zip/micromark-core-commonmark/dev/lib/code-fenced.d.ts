/** @type {Construct} */
export const codeFenced: Construct;
import type { Construct } from 'micromark-util-types';
//# sourceMappingURL=code-fenced.d.ts.map