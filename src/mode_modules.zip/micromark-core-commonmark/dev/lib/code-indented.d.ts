/** @type {Construct} */
export const codeIndented: Construct;
import type { Construct } from 'micromark-util-types';
//# sourceMappingURL=code-indented.d.ts.map