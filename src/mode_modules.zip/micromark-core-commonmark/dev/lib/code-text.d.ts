/** @type {Construct} */
export const codeText: Construct;
import type { Construct } from 'micromark-util-types';
//# sourceMappingURL=code-text.d.ts.map