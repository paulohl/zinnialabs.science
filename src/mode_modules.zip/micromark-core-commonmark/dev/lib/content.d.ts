/**
 * No name because it must not be turned off.
 * @type {Construct}
 */
export const content: Construct;
import type { Construct } from 'micromark-util-types';
//# sourceMappingURL=content.d.ts.map