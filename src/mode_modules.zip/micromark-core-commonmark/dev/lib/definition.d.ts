/** @type {Construct} */
export const definition: Construct;
import type { Construct } from 'micromark-util-types';
//# sourceMappingURL=definition.d.ts.map