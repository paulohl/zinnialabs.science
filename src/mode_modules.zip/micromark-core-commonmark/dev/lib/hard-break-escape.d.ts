/** @type {Construct} */
export const hardBreakEscape: Construct;
import type { Construct } from 'micromark-util-types';
//# sourceMappingURL=hard-break-escape.d.ts.map