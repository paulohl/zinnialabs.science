/** @type {Construct} */
export const headingAtx: Construct;
import type { Construct } from 'micromark-util-types';
//# sourceMappingURL=heading-atx.d.ts.map