/** @type {Construct} */
export const labelStartLink: Construct;
import type { Construct } from 'micromark-util-types';
//# sourceMappingURL=label-start-link.d.ts.map