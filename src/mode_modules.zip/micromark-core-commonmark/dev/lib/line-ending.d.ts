/** @type {Construct} */
export const lineEnding: Construct;
import type { Construct } from 'micromark-util-types';
//# sourceMappingURL=line-ending.d.ts.map