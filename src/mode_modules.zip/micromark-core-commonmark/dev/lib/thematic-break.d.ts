/** @type {Construct} */
export const thematicBreak: Construct;
import type { Construct } from 'micromark-util-types';
//# sourceMappingURL=thematic-break.d.ts.map