// Note: types are exported from `dev/index.d.ts`.
export {gfmFootnote} from './lib/syntax.js'
export {gfmFootnoteHtml, defaultBackLabel} from './lib/html.js'
