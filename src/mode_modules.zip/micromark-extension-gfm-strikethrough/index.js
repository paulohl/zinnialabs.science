// Note: more types exposed from `index.d.ts`.
export { gfmStrikethroughHtml } from './lib/html.js';
export { gfmStrikethrough } from './lib/syntax.js';