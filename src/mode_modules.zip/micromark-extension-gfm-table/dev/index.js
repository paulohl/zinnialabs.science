export {gfmTableHtml} from './lib/html.js'
export {gfmTable} from './lib/syntax.js'
