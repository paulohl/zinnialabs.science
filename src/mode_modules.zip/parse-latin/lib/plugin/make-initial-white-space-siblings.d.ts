export const makeInitialWhiteSpaceSiblings: import("../../node_modules/unist-util-visit-children/lib/index.js").Visit<import("nlcst").Paragraph | import("nlcst").Root>;
export type Paragraph = import('nlcst').Paragraph;
export type Root = import('nlcst').Root;
