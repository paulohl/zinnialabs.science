export const mergeInnerWordSlash: import("../../node_modules/unist-util-modify-children/lib/index.js").Modify<import("nlcst").Sentence>;
export type Sentence = import('nlcst').Sentence;
export type SentenceContent = import('nlcst').SentenceContent;
export type WordContent = import('nlcst').WordContent;
