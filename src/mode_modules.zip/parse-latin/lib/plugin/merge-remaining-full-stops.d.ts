export const mergeRemainingFullStops: import("../../node_modules/unist-util-visit-children/lib/index.js").Visit<import("nlcst").Paragraph>;
export type Paragraph = import('nlcst').Paragraph;
