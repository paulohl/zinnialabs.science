export const patchPosition: import("../../node_modules/unist-util-visit-children/lib/index.js").Visit<import("nlcst").Sentence | import("nlcst").Paragraph | import("nlcst").Root>;
export type Node = import('unist').Node;
export type Paragraph = import('nlcst').Paragraph;
export type Position = import('unist').Position;
export type Root = import('nlcst').Root;
export type Sentence = import('nlcst').Sentence;
