export const removeEmptyNodes: import("../../node_modules/unist-util-modify-children/lib/index.js").Modify<import("nlcst").Paragraph | import("nlcst").Root>;
export type Paragraph = import('nlcst').Paragraph;
export type Root = import('nlcst').Root;
