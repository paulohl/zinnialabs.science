/**
 * @param {string} value
 * @returns {string | false}
 */
export function decodeNamedCharacterReference(value: string): string | false;
//# sourceMappingURL=index.dom.d.ts.map