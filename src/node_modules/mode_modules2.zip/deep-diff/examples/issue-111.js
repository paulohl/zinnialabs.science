var diff = require('../');


var differences = diff(undefined, undefined);
// eslint-disable-next-line no-console
console.log(differences);
