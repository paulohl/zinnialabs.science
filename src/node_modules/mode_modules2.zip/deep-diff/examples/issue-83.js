var deepDiff = require("../");

var left = {
  date: null
};

var right = {
  date: null
};

console.log(deepDiff(left, right));
