export declare const GelViewConfig: unique symbol;
