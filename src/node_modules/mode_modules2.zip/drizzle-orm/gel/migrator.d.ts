declare function migrate<TSchema extends Record<string, unknown>>(): Promise<{}>;
