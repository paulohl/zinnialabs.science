async function migrate() {
  return {};
}
//# sourceMappingURL=migrator.js.map