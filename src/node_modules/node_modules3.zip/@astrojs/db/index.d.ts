import './virtual.js';

export { default, cli } from './dist/index.js';
