"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FIXED_32 = exports.GROUP_END = exports.GROUP_START = exports.LENGTH_DELIMITED = exports.FIXED_64 = exports.VARINT = void 0;
exports.VARINT = 0;
exports.FIXED_64 = 1;
exports.LENGTH_DELIMITED = 2;
exports.GROUP_START = 3;
exports.GROUP_END = 4;
exports.FIXED_32 = 5;
