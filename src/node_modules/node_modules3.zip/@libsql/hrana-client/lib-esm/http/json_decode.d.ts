import * as d from "../encoding/json/decode.js";
import * as proto from "./proto.js";
export declare function PipelineRespBody(obj: d.Obj): proto.PipelineRespBody;
export declare function CursorRespBody(obj: d.Obj): proto.CursorRespBody;
