import * as e from "../encoding/json/encode.js";
import * as proto from "./proto.js";
export declare function PipelineReqBody(w: e.ObjectWriter, msg: proto.PipelineReqBody): void;
export declare function CursorReqBody(w: e.ObjectWriter, msg: proto.CursorReqBody): void;
