// Types for the structures specific to Hrana over HTTP.
export * from "../shared/proto.js";
