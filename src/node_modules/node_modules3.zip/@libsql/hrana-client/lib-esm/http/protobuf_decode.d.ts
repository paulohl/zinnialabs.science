import * as d from "../encoding/protobuf/decode.js";
import * as proto from "./proto.js";
export declare const PipelineRespBody: d.MessageDef<proto.PipelineRespBody>;
export declare const CursorRespBody: d.MessageDef<proto.CursorRespBody>;
