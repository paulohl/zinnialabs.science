import * as e from "../encoding/protobuf/encode.js";
import * as proto from "./proto.js";
export declare function PipelineReqBody(w: e.MessageWriter, msg: proto.PipelineReqBody): void;
export declare function CursorReqBody(w: e.MessageWriter, msg: proto.CursorReqBody): void;
