export declare class IdAlloc {
    #private;
    constructor();
    alloc(): number;
    free(id: number): void;
}
