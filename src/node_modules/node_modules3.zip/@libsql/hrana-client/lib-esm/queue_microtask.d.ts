declare let _queueMicrotask: (callback: () => void) => void;
export { _queueMicrotask as queueMicrotask };
