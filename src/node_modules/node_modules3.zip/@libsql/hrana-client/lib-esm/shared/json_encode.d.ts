import * as e from "../encoding/json/encode.js";
import * as proto from "./proto.js";
export declare function Stmt(w: e.ObjectWriter, msg: proto.Stmt): void;
export declare function Batch(w: e.ObjectWriter, msg: proto.Batch): void;
