// Types for the protocol structures that are shared for WebSocket and HTTP
export {};
