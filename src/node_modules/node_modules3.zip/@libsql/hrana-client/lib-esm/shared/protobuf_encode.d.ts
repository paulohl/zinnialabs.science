import * as e from "../encoding/protobuf/encode.js";
import * as proto from "./proto.js";
export declare function Stmt(w: e.MessageWriter, msg: proto.Stmt): void;
export declare function Batch(w: e.MessageWriter, msg: proto.Batch): void;
