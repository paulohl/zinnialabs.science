export declare function impossible(value: never, message: string): Error;
