import * as d from "../encoding/json/decode.js";
import * as proto from "./proto.js";
export declare function ServerMsg(obj: d.Obj): proto.ServerMsg;
