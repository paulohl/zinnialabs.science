import * as e from "../encoding/json/encode.js";
import * as proto from "./proto.js";
export declare function ClientMsg(w: e.ObjectWriter, msg: proto.ClientMsg): void;
