import * as d from "../encoding/protobuf/decode.js";
import * as proto from "./proto.js";
export declare const ServerMsg: d.MessageDef<proto.ServerMsg>;
