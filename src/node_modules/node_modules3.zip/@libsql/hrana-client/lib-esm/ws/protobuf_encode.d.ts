import * as e from "../encoding/protobuf/encode.js";
import * as proto from "./proto.js";
export declare function ClientMsg(w: e.MessageWriter, msg: proto.ClientMsg): void;
