"use strict";
module.exports.fetch = fetch;
module.exports.Request = Request;
module.exports.Headers = Headers;
