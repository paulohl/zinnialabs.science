# `@libsql/win32-x64-msvc`

Prebuilt binary package for `libsql` on `win32-x64-msvc`.
