export declare function currentTarget(): string;
export declare function load(dirname: string): any;
