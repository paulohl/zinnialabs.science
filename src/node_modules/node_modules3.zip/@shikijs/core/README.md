# @shikijs/core

The core functionality of [Shiki](https://github.com/shikijs/shiki), without any grammar of themes bundled.

It's the same as importing `shiki/core`.
