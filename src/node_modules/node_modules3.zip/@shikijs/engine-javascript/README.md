# @shikijs/engine-javascript

Engine for Shiki using JavaScript's native RegExp. Uses [Oniguruma-To-ES](https://github.com/slevithan/oniguruma-to-es) to transpile regex syntax and behavior.

[Documentation](https://shiki.style/guide/regex-engines)

## License

MIT
