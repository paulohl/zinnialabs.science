# @shikijs/engine-oniguruma

Engine for Shiki using Oniguruma RegExp engine in WebAssembly.

[Documentation](https://shiki.style/guide/regex-engines)

## License

MIT
