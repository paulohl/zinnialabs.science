# @shikijs/langs

TextMate grammars for Shiki.

## License

MIT
