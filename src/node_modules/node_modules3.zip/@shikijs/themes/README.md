# @shikijs/themes

TextMate themes for Shiki.

## License

MIT
