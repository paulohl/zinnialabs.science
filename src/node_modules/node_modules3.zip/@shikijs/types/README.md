# @shikijs/types

Types for Shiki.

## License

MIT
