export { _ as default } from "../esm/_check_private_redeclaration.js";
