export { _ as default } from "../esm/_is_native_function.js";
