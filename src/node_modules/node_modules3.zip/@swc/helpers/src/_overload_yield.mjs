export { _ as default } from "../esm/_overload_yield.js";
