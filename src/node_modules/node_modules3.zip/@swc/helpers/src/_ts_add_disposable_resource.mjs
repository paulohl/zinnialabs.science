export { _ as default } from "../esm/_ts_add_disposable_resource.js";
